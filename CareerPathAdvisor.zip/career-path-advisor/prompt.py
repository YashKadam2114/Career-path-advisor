"""
prompt.py
---------
Contains the System Prompt and User Prompt generation functions for the
Career Path Advisor AI application.
"""

import json

SYSTEM_PROMPT = """You are an experienced AI career guidance expert, technical career counsellor, and professional learning roadmap designer.

Your task is to analyse a student's academic background, interests, technical skills, personal strengths, preferred working style, experience level, and career ambitions.

Based on the complete profile, recommend exactly THREE suitable career paths.

Your recommendations must be personalised, realistic, practical, and suitable for the student's current skill level.

Do not give generic recommendations.

For every recommended career, provide:

1. Career title.
2. Career overview.
3. Why this career suits the student.
4. Skills the student already possesses that are relevant.
5. Missing skills that the student should develop.
6. Important tools and technologies to learn.
7. Beginner-friendly projects to build.
8. Career opportunities and possible job roles.
9. A detailed three-month learning roadmap.

The roadmap must be divided into:

MONTH 1 – FOUNDATION
- Weekly learning goals.
- Concepts to understand.
- Technologies to practise.
- Practical exercises.

MONTH 2 – SKILL DEVELOPMENT
- Weekly learning goals.
- Intermediate concepts.
- Hands-on exercises.
- Mini project development.

MONTH 3 – PRACTICAL IMPLEMENTATION
- Weekly learning goals.
- Real-world project.
- GitHub portfolio preparation.
- Resume and interview preparation.

For each month, include measurable learning outcomes.

Adapt the roadmap according to the student's available daily learning hours and experience level.

Provide a realistic assessment. Do not guarantee employment, salary, or placement.

If information is insufficient, clearly mention the assumptions.

Return the result in valid structured JSON adhering strictly to the schema provided.

Do not invent student qualifications or skills."""


def build_user_prompt(profile: dict) -> str:
    """
    Constructs a detailed structured prompt for Gemini based on student inputs.
    """
    fav_subjects = ", ".join(profile.get("favourite_subjects", [])) or "None specified"
    tech_skills = ", ".join(profile.get("technical_skills", [])) or "None specified"
    personal_interests = ", ".join(profile.get("personal_interests", [])) or "None specified"
    strongest_skills = ", ".join(profile.get("strongest_skills", [])) or "None specified"

    user_prompt = f"""Please analyse the following student profile and generate a comprehensive career recommendation report with exactly THREE distinct career paths and detailed 3-month roadmaps.

STUDENT PROFILE DETAILS:
- Name: {profile.get('student_name', 'Student')}
- Education Level: {profile.get('education_level', 'Not specified')}
- Degree / Branch: {profile.get('degree_branch', 'Not specified')}
- Favourite Academic Subjects: {fav_subjects}
- Current Technical Skills: {tech_skills}
- Personal Interests: {personal_interests}
- Strongest Personal / Soft Skills: {strongest_skills}
- Preferred Working Style: {profile.get('preferred_working_style', 'Both')}
- Expressed Career Goal / Dream Role: {profile.get('career_goal', 'Not Sure Yet')}
- Technical Experience Level: {profile.get('experience_level', 'Beginner')}
- Daily Learning Availability: {profile.get('daily_learning_availability', '2 Hours')}
- Additional Context / Ambitions: {profile.get('additional_info', 'None provided')}

STRICT JSON OUTPUT REQUIREMENT:
You must respond with ONLY a valid, parseable JSON object matching this exact structure:
{{
  "profile_summary": "Comprehensive 2-3 sentence summary of the student's profile, aptitude, and current readiness",
  "career_recommendations": [
    {{
      "career_title": "Specific Career Title (e.g. Full-Stack Web Developer, Machine Learning Engineer, Data Analyst)",
      "suitability_score": 92,
      "career_overview": "A clear, compelling 2-3 sentence overview of this profession and why it is thriving in industry today",
      "why_suitable": [
        "First personalized reason highlighting existing skills/interests",
        "Second reason based on academic strengths or career goal",
        "Third reason matching working style and experience level"
      ],
      "existing_relevant_skills": ["Skill 1", "Skill 2"],
      "missing_skills": ["Missing Skill 1", "Missing Skill 2", "Missing Skill 3"],
      "tools_and_technologies": ["Tool/Tech 1", "Tool/Tech 2", "Tool/Tech 3", "Tool/Tech 4"],
      "suggested_projects": [
        "Project 1: Short description of a beginner-friendly project",
        "Project 2: Short description of an intermediate portfolio project"
      ],
      "job_roles": ["Role 1", "Role 2", "Role 3"],
      "roadmap": {{
        "month_1": {{
          "title": "Foundation",
          "weeks": [
            {{
              "week": 1,
              "topics": ["Core concept 1", "Core concept 2"],
              "tasks": ["Practical exercise 1", "Code task 2"],
              "outcome": "Clear measurable outcome for Week 1"
            }},
            {{
              "week": 2,
              "topics": ["Topic 1", "Topic 2"],
              "tasks": ["Task 1", "Task 2"],
              "outcome": "Measurable outcome for Week 2"
            }},
            {{
              "week": 3,
              "topics": ["Topic 1", "Topic 2"],
              "tasks": ["Task 1", "Task 2"],
              "outcome": "Measurable outcome for Week 3"
            }},
            {{
              "week": 4,
              "topics": ["Topic 1", "Topic 2"],
              "tasks": ["Task 1", "Task 2"],
              "outcome": "Measurable outcome for Week 4 (Month 1 Cap)"
            }}
          ]
        }},
        "month_2": {{
          "title": "Skill Development",
          "weeks": [
            {{
              "week": 5,
              "topics": ["Intermediate concept 1", "Intermediate concept 2"],
              "tasks": ["Task 1", "Task 2"],
              "outcome": "Measurable outcome for Week 5"
            }},
            {{
              "week": 6,
              "topics": ["Topic 1", "Topic 2"],
              "tasks": ["Task 1", "Task 2"],
              "outcome": "Measurable outcome for Week 6"
            }},
            {{
              "week": 7,
              "topics": ["Topic 1", "Topic 2"],
              "tasks": ["Task 1", "Task 2"],
              "outcome": "Measurable outcome for Week 7"
            }},
            {{
              "week": 8,
              "topics": ["Mini-project architecture", "Integration"],
              "tasks": ["Build mini project", "Write unit tests"],
              "outcome": "Completed functional mini-project"
            }}
          ]
        }},
        "month_3": {{
          "title": "Practical Implementation",
          "weeks": [
            {{
              "week": 9,
              "topics": ["Real-world system design", "API deployment"],
              "tasks": ["Initiate capstone project", "Setup repository"],
              "outcome": "Capstone project core functionality operational"
            }},
            {{
              "week": 10,
              "topics": ["Feature completion", "Documentation"],
              "tasks": ["Add advanced features", "Write clean README"],
              "outcome": "Production-ready portfolio project"
            }},
            {{
              "week": 11,
              "topics": ["GitHub profile curation", "Project deployment (Cloud/Vercel/Render)"],
              "tasks": ["Deploy live application", "Write architecture blog/post"],
              "outcome": "Live public demo and clean GitHub repo"
            }},
            {{
              "week": 12,
              "topics": ["Technical interview questions", "Resume tailoring"],
              "tasks": ["Mock interviews", "Apply to entry-level roles/internships"],
              "outcome": "Polished technical resume and interview readiness"
            }}
          ]
        }}
      }}
    }}
  ],
  "overall_recommendation": "A thoughtful 3-4 sentence closing guidance statement advising the student on their next immediate step, mindset, and continuous learning strategy."
}}

CRITICAL INSTRUCTIONS:
1. Return valid JSON only. Do not wrap in markdown quotes if possible, or use standard ```json ``` formatting.
2. The `career_recommendations` array MUST contain exactly THREE recommendations.
3. Keep the advice realistic, tailored to their {profile.get('daily_learning_availability', '2 Hours')} daily availability.
"""
    return user_prompt
