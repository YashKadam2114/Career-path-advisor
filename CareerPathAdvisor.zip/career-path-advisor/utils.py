"""
utils.py
--------
Helper utilities for Career Path Advisor:
- Input validation
- Robust JSON parsing and schema sanitization
- Pre-configured test profiles (5 test cases)
- Dynamic fallback recommendation generator (for offline/demo reliability)
- Professional PDF report generation using ReportLab
"""

import io
import json
import re
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    HRFlowable,
    KeepTogether
)


def validate_inputs(profile: dict) -> tuple[bool, list[str]]:
    """
    Validates user input fields before submitting to AI.
    Returns (is_valid, list_of_error_messages).
    """
    errors = []
    name = profile.get("student_name", "").strip()
    if not name:
        errors.append("Student Name is required.")
    elif len(name) < 2:
        errors.append("Student Name must be at least 2 characters long.")

    if not profile.get("education_level"):
        errors.append("Please select your Education Level.")

    if not profile.get("degree_branch"):
        errors.append("Please select your Degree / Branch.")

    tech_skills = profile.get("technical_skills", [])
    fav_subjects = profile.get("favourite_subjects", [])
    interests = profile.get("personal_interests", [])

    if not tech_skills and not fav_subjects and not interests:
        errors.append("Please select at least one technical skill, favourite subject, or personal interest.")

    return len(errors) == 0, errors


def parse_json_response(raw_text: str) -> dict:
    """
    Safely extracts and parses JSON from the LLM response text.
    Handles markdown code blocks, trailing commas, and partial structures.
    """
    if not raw_text or not isinstance(raw_text, str):
        raise ValueError("Empty or invalid response from AI service.")

    cleaned = raw_text.strip()

    # Extract content inside markdown ```json ... ``` or ``` ... ```
    json_match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", cleaned)
    if json_match:
        cleaned = json_match.group(1).strip()
    else:
        # Try to find the outermost { ... }
        start_idx = cleaned.find("{")
        end_idx = cleaned.rfind("}")
        if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
            cleaned = cleaned[start_idx : end_idx + 1]

    # Attempt direct JSON decode
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        # Clean trailing commas before closing braces/brackets
        cleaned_lenient = re.sub(r",\s*([\]}])", r"\1", cleaned)
        data = json.loads(cleaned_lenient)

    # Sanitize and ensure structure
    return sanitize_career_data(data)


def sanitize_career_data(data: dict) -> dict:
    """
    Ensures all expected keys and list lengths exist in the parsed AI output.
    """
    if not isinstance(data, dict):
        raise ValueError("Parsed output is not a JSON dictionary.")

    profile_summary = data.get("profile_summary", "Profile analysis generated successfully.")
    career_recs = data.get("career_recommendations", [])
    overall_rec = data.get("overall_recommendation", "Continue upskilling with consistent daily practice.")

    if not isinstance(career_recs, list) or len(career_recs) == 0:
        raise ValueError("AI response did not contain career recommendations.")

    sanitized_recs = []
    for i, rec in enumerate(career_recs[:3]):
        title = rec.get("career_title", f"Career Option {i+1}")
        score = rec.get("suitability_score", 85)
        try:
            score = int(score)
            score = max(50, min(100, score))
        except (ValueError, TypeError):
            score = 85

        overview = rec.get("career_overview", "A strong career pathway matching your core strengths.")
        why_suitable = rec.get("why_suitable", ["Matches your technical skills", "High market demand"])
        existing_skills = rec.get("existing_relevant_skills", [])
        missing_skills = rec.get("missing_skills", [])
        tools = rec.get("tools_and_technologies", [])
        projects = rec.get("suggested_projects", [])
        job_roles = rec.get("job_roles", [])
        roadmap = rec.get("roadmap", {})

        # Ensure roadmap has months 1, 2, 3
        sanitized_roadmap = {}
        for m_key, m_default_title in [
            ("month_1", "Foundation"),
            ("month_2", "Skill Development"),
            ("month_3", "Practical Implementation"),
        ]:
            m_data = roadmap.get(m_key, {})
            title_m = m_data.get("title", m_default_title)
            weeks = m_data.get("weeks", [])
            if not weeks or not isinstance(weeks, list):
                weeks = [
                    {
                        "week": 1 if m_key == "month_1" else (5 if m_key == "month_2" else 9),
                        "topics": ["Foundational core concepts", "Architecture overview"],
                        "tasks": ["Hands-on practice problems", "Setup dev environment"],
                        "outcome": "Strong grasp of the foundational tools and syntax.",
                    }
                ]
            sanitized_roadmap[m_key] = {"title": title_m, "weeks": weeks}

        sanitized_recs.append(
            {
                "career_title": title,
                "suitability_score": score,
                "career_overview": overview,
                "why_suitable": why_suitable if isinstance(why_suitable, list) else [str(why_suitable)],
                "existing_relevant_skills": existing_skills if isinstance(existing_skills, list) else [],
                "missing_skills": missing_skills if isinstance(missing_skills, list) else [],
                "tools_and_technologies": tools if isinstance(tools, list) else [],
                "suggested_projects": projects if isinstance(projects, list) else [],
                "job_roles": job_roles if isinstance(job_roles, list) else [],
                "roadmap": sanitized_roadmap,
            }
        )

    return {
        "profile_summary": profile_summary,
        "career_recommendations": sanitized_recs,
        "overall_recommendation": overall_rec,
    }


def get_sample_profiles() -> dict[str, dict]:
    """
    Returns five pre-configured student test profiles for viva demonstration and testing.
    """
    return {
        "1. Computer Science (Java & Software Dev)": {
            "student_name": "Arjun Sharma",
            "education_level": "Undergraduate",
            "degree_branch": "Computer Science",
            "favourite_subjects": ["Programming", "Database Management", "Web Development"],
            "technical_skills": ["Java", "SQL", "Spring Boot", "HTML/CSS"],
            "personal_interests": ["Software Development", "Problem Solving", "Web Development"],
            "strongest_skills": ["Problem Solving", "Logical Thinking", "Teamwork"],
            "preferred_working_style": "Both",
            "career_goal": "Software Developer",
            "experience_level": "Intermediate",
            "daily_learning_availability": "3 Hours",
            "additional_info": "I want to build enterprise backend systems and scalable web applications in product companies.",
        },
        "2. Mathematics & Python (Data Science)": {
            "student_name": "Priya Patel",
            "education_level": "Undergraduate",
            "degree_branch": "Information Technology",
            "favourite_subjects": ["Mathematics", "Programming", "Machine Learning"],
            "technical_skills": ["Python", "SQL", "Data Analysis"],
            "personal_interests": ["Data Science", "Research", "Problem Solving"],
            "strongest_skills": ["Analytical Thinking", "Logical Thinking", "Problem Solving"],
            "preferred_working_style": "Individual Work",
            "career_goal": "Data Scientist",
            "experience_level": "Intermediate",
            "daily_learning_availability": "2 Hours",
            "additional_info": "I love discovering statistical patterns, data visualization, and building predictive analytics models.",
        },
        "3. AI & Deep Learning Enthusiast": {
            "student_name": "Rohan Verma",
            "education_level": "Postgraduate",
            "degree_branch": "Computer Science",
            "favourite_subjects": ["Artificial Intelligence", "Machine Learning", "Mathematics"],
            "technical_skills": ["Python", "Machine Learning", "Data Analysis", "C/C++"],
            "personal_interests": ["Artificial Intelligence", "Research", "Software Development"],
            "strongest_skills": ["Analytical Thinking", "Creativity", "Problem Solving"],
            "preferred_working_style": "Both",
            "career_goal": "AI/ML Engineer",
            "experience_level": "Advanced",
            "daily_learning_availability": "4+ Hours",
            "additional_info": "Passionate about generative models, deep learning vision systems, and deploying LLM pipelines.",
        },
        "4. Cybersecurity & Networking Specialist": {
            "student_name": "Sneha Kulkarni",
            "education_level": "Undergraduate",
            "degree_branch": "Electronics",
            "favourite_subjects": ["Programming", "Communication"],
            "technical_skills": ["C/C++", "Python", "SQL"],
            "personal_interests": ["Cybersecurity", "Problem Solving"],
            "strongest_skills": ["Logical Thinking", "Problem Solving", "Analytical Thinking"],
            "preferred_working_style": "Team Work",
            "career_goal": "Cybersecurity Analyst",
            "experience_level": "Beginner",
            "daily_learning_availability": "2 Hours",
            "additional_info": "Interested in ethical hacking, vulnerability assessments, penetration testing, and network security.",
        },
        "5. General / Undecided Beginner": {
            "student_name": "Aman Gupta",
            "education_level": "Undergraduate",
            "degree_branch": "Commerce",
            "favourite_subjects": ["Business Management", "Communication"],
            "technical_skills": ["HTML/CSS"],
            "personal_interests": ["Business and Management", "Designing and Creativity", "Entrepreneurship"],
            "strongest_skills": ["Communication", "Leadership", "Creativity"],
            "preferred_working_style": "Both",
            "career_goal": "Not Sure Yet",
            "experience_level": "Beginner",
            "daily_learning_availability": "1 Hour",
            "additional_info": "I want to transition into tech management or digital product roles without requiring heavy math or hard coding.",
        },
    }


def generate_fallback_response(profile: dict) -> dict:
    """
    Generates a dynamic, high-quality, realistic recommendation response based on the
    student's profile if Gemini API is offline, unconfigured, or quota-limited.
    Guarantees the system always works reliably during viva presentations.
    """
    name = profile.get("student_name", "Student")
    goal = profile.get("career_goal", "Software Developer")
    tech_skills = profile.get("technical_skills", [])
    interests = profile.get("personal_interests", [])
    availability = profile.get("daily_learning_availability", "2 Hours")
    exp = profile.get("experience_level", "Beginner")

    # Match primary and secondary pathways based on input
    if "Data Scientist" in goal or "Data Science" in interests or "Data Analysis" in tech_skills:
        careers = [
            {
                "title": "Data Scientist",
                "score": 93,
                "overview": "Leverages statistical modeling, machine learning, and programming to extract actionable insights and predictive signals from complex datasets.",
                "why": [
                    f"Capitalizes on your interest in analytical thinking and {', '.join(tech_skills) if tech_skills else 'data'}.",
                    "Directly aligns with your target career path in quantitative technology.",
                    f"High industry demand across fintech, healthcare, and e-commerce."
                ],
                "existing": [s for s in tech_skills if s in ["Python", "SQL", "Data Analysis", "Machine Learning"]] or ["Foundational Analytical Aptitude"],
                "missing": ["Pandas & NumPy Advanced Profiling", "Scikit-Learn Regression & Classification", "Statistical Hypothesis Testing", "Data Storytelling with Tableau/PowerBI"],
                "tools": ["Python", "JupyterLab", "Pandas", "Scikit-Learn", "PostgreSQL", "Tableau"],
                "projects": [
                    "E-Commerce Customer Churn Prediction: Build an end-to-end classifier with feature importance visualization.",
                    "Exploratory Real Estate Price Predictor: Scrape, clean, and model regional housing price determinants."
                ],
                "roles": ["Junior Data Scientist", "Data Analyst", "Business Intelligence Associate"],
                "roadmaps": (
                    ["Python Data Stack (Pandas, NumPy)", "SQL queries and joins", "Exploratory Data Analysis", "Descriptive Statistics"],
                    ["Scikit-Learn Supervised Models", "Feature Engineering", "Model Evaluation (ROC-AUC, F1)", "Streamlit Analytics Dashboard"],
                    ["Unsupervised Learning & Clustering", "Model Packaging (FastAPI)", "GitHub Portfolio with Interactive Dashboards", "Data Science Mock Interview Preparation"]
                )
            },
            {
                "title": "Machine Learning Engineer",
                "score": 88,
                "overview": "Bridges the gap between data science experimentation and production software engineering by building scalable model pipelines.",
                "why": [
                    "Combines coding rigor with predictive algorithms.",
                    "Fastest growing AI engineering discipline globally.",
                    "Provides high salary growth potential and technical autonomy."
                ],
                "existing": [s for s in tech_skills if s in ["Python", "C/C++", "Machine Learning"]] or ["Programming Fundamentals"],
                "missing": ["MLOps & Model Serialization", "Docker & Containerized Serving", "FastAPI / Flask Endpoints", "Vector Databases & Embeddings"],
                "tools": ["Python", "PyTorch / Scikit-Learn", "FastAPI", "Docker", "MLflow", "Git"],
                "projects": [
                    "Real-Time Sentiment Classifier API: Host a containerized model that serves predictions under 50ms.",
                    "Content Recommendation Engine: Hybrid collaborative filtering pipeline for movies or books."
                ],
                "roles": ["Associate ML Engineer", "AI Systems Developer", "Applied ML Intern"],
                "roadmaps": (
                    ["Python OOP & Clean Code", "Mathematics for ML (Linear Algebra, Calculus)", "Scikit-Learn Essentials", "Data Preprocessing Pipelines"],
                    ["Neural Network Foundations", "Model Optimization & Tuning", "FastAPI Serving Architecture", "Docker Containerization"],
                    ["MLOps Lifecycle Basics", "CI/CD Model Testing", "Portfolio Capstone Deployment on Cloud", "ML Interview Problem Solving"]
                )
            },
            {
                "title": "Business Intelligence & Analytics Engineer",
                "score": 84,
                "overview": "Transforms raw company databases into live operational dashboards and KPI pipelines that guide executive strategic decisions.",
                "why": [
                    "Immediate market applicability with rapid entry pathways.",
                    "Balances business acumen with hands-on data querying.",
                    "Permits rapid project portfolio creation within 3 months."
                ],
                "existing": [s for s in tech_skills if s in ["SQL", "Data Analysis", "Python"]] or ["Structured Thinking"],
                "missing": ["Data Warehousing (Snowflake/BigQuery)", "Power BI / Tableau DAX Formulas", "Dimensional Modeling (Star Schema)", "dbt (Data Build Tool)"],
                "tools": ["SQL", "Power BI", "Snowflake / Postgres", "Python", "Excel Power Query"],
                "projects": [
                    "SaaS Revenue Retention Dashboard: Interactive executive report tracking MRR, churn rate, and CAC.",
                    "Supply Chain Optimization Analysis: SQL data pipeline resolving delivery bottleneck anomalies."
                ],
                "roles": ["BI Analyst", "Analytics Engineer", "Data Operations Specialist"],
                "roadmaps": (
                    ["Advanced SQL (Window Functions, CTEs)", "Relational Database Normalization", "Excel Advanced Analytics", "Business Metrics & KPIs"],
                    ["Power BI & Tableau Dashboarding", "Data Modeling & Star Schema", "Automated Python ETL Scripts", "Interactive Dashboard Project"],
                    ["Data Warehousing Fundamentals", "Portfolio Storytelling & Case Studies", "LinkedIn Technical Brand & Resume Review", "SQL & Case Study Interview Prep"]
                )
            }
        ]
    elif "Cybersecurity" in goal or "Cybersecurity" in interests:
        careers = [
            {
                "title": "Cybersecurity Analyst",
                "score": 92,
                "overview": "Monitors network traffic, identifies vulnerabilities, investigates security breaches, and protects enterprise digital infrastructure from malicious threats.",
                "why": [
                    "Matches your interest in security protocols, networks, and problem-solving.",
                    "Critical shortage of skilled cybersecurity practitioners globally.",
                    "Offers clear certifications (CompTIA Security+, CEH) and well-defined progression."
                ],
                "existing": [s for s in tech_skills if s in ["C/C++", "Python", "SQL"]] or ["Analytical Mindset"],
                "missing": ["Network Traffic Analysis (Wireshark)", "SIEM Tooling (Splunk / Elastic)", "Linux CLI & System Hardening", "OWASP Top 10 Web Vulnerabilities"],
                "tools": ["Linux (Kali/Ubuntu)", "Wireshark", "Nmap", "Splunk", "Python", "Metasploit"],
                "projects": [
                    "Home SOC & SIEM Lab: Deploy a VirtualBox virtual network, configure Splunk, and analyze simulated brute-force attacks.",
                    "Automated Vulnerability Scanner: Python script that checks open ports and banners against CVE databases."
                ],
                "roles": ["SOC Analyst Tier 1", "Information Security Specialist", "Vulnerability Analyst"],
                "roadmaps": (
                    ["TCP/IP, OSI Model & Subnetting", "Linux Command Line & Bash", "Network Scanning with Nmap", "Security Fundamentals (CIA Triad)"],
                    ["Wireshark Packet Inspection", "SIEM Architecture & Splunk Queries", "OWASP Top 10 Deep Dive", "Virtual Lab Incident Response Simulation"],
                    ["Security Hardening & Scripting", "CompTIA Security+ Blueprint Review", "GitHub SOC Lab Documentation", "SOC Technical Scenario Interview Prep"]
                )
            },
            {
                "title": "Cloud Security Associate",
                "score": 87,
                "overview": "Specializes in securing AWS, Azure, and Google Cloud environments, configuring IAM policies, encryption, and automated posture management.",
                "why": [
                    "Massive corporate migration to multi-cloud architectures.",
                    "Blends modern cloud technologies with critical security practices.",
                    "High starting packages for junior cloud defenders."
                ],
                "existing": [s for s in tech_skills if s in ["Python", "SQL"]] or ["System Design Aptitude"],
                "missing": ["AWS / Azure IAM & Policies", "Terraform Infrastructure as Code", "Container Security (Docker/Kubernetes)", "Cloud Compliance Frameworks"],
                "tools": ["AWS CloudWatch & IAM", "Terraform", "Docker", "Linux", "Trivy", "Git"],
                "projects": [
                    "Zero-Trust Cloud Architecture: Deploy a secure VPC with private subnets, bastion hosts, and strict IAM roles.",
                    "Automated Docker Security Pipeline: Integrate container vulnerability scanning in GitHub Actions."
                ],
                "roles": ["Cloud Security Engineer Intern", "Junior DevSecOps Engineer", "Cloud Infrastructure Analyst"],
                "roadmaps": (
                    ["Cloud Computing Fundamentals (AWS/Azure)", "IAM Roles, Policies & MFA", "VPC & Security Groups", "Linux Shell Configuration"],
                    ["Infrastructure as Code (Terraform)", "Secrets Management (HashiCorp Vault/KMS)", "Container Security Basics", "Automated Audit Script in Python"],
                    ["DevSecOps CI/CD Integration", "Cloud Penetration Testing Ethics", "Public GitHub Cloud Security Architecture Repo", "Cloud Interview Preparation"]
                )
            },
            {
                "title": "Penetration Tester / Ethical Hacker",
                "score": 84,
                "overview": "Performs authorized simulated cyberattacks on corporate networks, web applications, and endpoints to expose and remediate flaws.",
                "why": [
                    "Directly appeals to hands-on problem solvers and investigative thinkers.",
                    "High thrill, high challenge environment with bug bounty opportunities.",
                    "Demonstrable through CTF (Capture the Flag) ranking and CVE reports."
                ],
                "existing": [s for s in tech_skills if s in ["C/C++", "Python", "HTML/CSS"]] or ["Curiosity & Logical Reasoning"],
                "missing": ["Burp Suite Professional Workflows", "Web Exploitation (SQLi, XSS, CSRF)", "Privilege Escalation Techniques", "Professional Penetration Testing Reports"],
                "tools": ["Burp Suite", "Kali Linux", "Gobuster", "Hydra", "Python", "Metasploit"],
                "projects": [
                    "OverTheWire & TryHackMe Walkthrough Portfolio: Detailed writeups for 10 challenging vulnerable boxes.",
                    "Custom Web Reconnaissance CLI: Python tool that maps subdomains and detects outdated CMS headers."
                ],
                "roles": ["Junior Penetration Tester", "AppSec Associate", "Security Consultant"],
                "roadmaps": (
                    ["Web Architecture & HTTP Headers", "Burp Suite Proxy Basics", "SQL Injection & Cross-Site Scripting", "TryHackMe Bandit & Web Fundamentals"],
                    ["Network Reconnaissance & Exploitation", "Linux & Windows Privilege Escalation", "Python Security Automation", "Active Directory Security Basics"],
                    ["CTF Competition Participation", "Professional Remediation Report Writing", "GitHub Penetration Testing Portfolio", "Technical Interview & Live Box Defense"]
                )
            }
        ]
    elif "AI/ML Engineer" in goal or "Artificial Intelligence" in interests:
        careers = [
            {
                "title": "AI & Generative AI Solutions Engineer",
                "score": 94,
                "overview": "Builds, fine-tunes, and integrates Large Language Models (LLMs), RAG pipelines, and autonomous AI agents into modern production software.",
                "why": [
                    "Capitalizes on your interest in cutting-edge AI and programming.",
                    "Explosive industry transformation driven by LLMs and foundation models.",
                    "High creative autonomy and project-based portfolio impact."
                ],
                "existing": [s for s in tech_skills if s in ["Python", "Machine Learning", "Data Analysis"]] or ["Algorithmic Foundation"],
                "missing": ["LangChain & LlamaIndex", "Vector Databases (Chroma/Pinecone)", "RAG (Retrieval-Augmented Generation)", "Prompt Engineering & Evaluation Frameworks"],
                "tools": ["Python", "Gemini API", "LangChain", "ChromaDB", "Streamlit", "Docker"],
                "projects": [
                    "Enterprise Document Intelligence System: Multi-PDF conversational assistant using Gemini and Vector Search.",
                    "AI Autonomous Research Agent: Multi-step agent that browses web articles and outputs synthesized summaries."
                ],
                "roles": ["AI Solutions Engineer", "Generative AI Developer", "Applied AI Specialist"],
                "roadmaps": (
                    ["Python Modern Async & Typing", "LLM APIs (Gemini, Claude, OpenAI)", "Prompt Engineering & Few-Shot Learning", "Vector Embeddings & Semantic Search"],
                    ["Retrieval-Augmented Generation (RAG)", "LangChain & LlamaIndex Chains", "ChromaDB Vector Store Integration", "Building Interactive AI Apps with Streamlit"],
                    ["Agentic Workflows & Tool Calling", "LLM Evaluation & Guardrails", "Live Cloud Deployment & GitHub Case Study", "AI Systems Technical Interview Preparation"]
                )
            },
            {
                "title": "Machine Learning Engineer",
                "score": 90,
                "overview": "Designs, trains, and optimizes machine learning architectures, ensuring models execute reliably with high throughput in production.",
                "why": [
                    "Strong fit for your technical background and problem-solving skills.",
                    "Provides deep foundational knowledge across mathematical and applied disciplines.",
                    "Solid career longevity and clear advancement into Senior ML Architect."
                ],
                "existing": [s for s in tech_skills if s in ["Python", "Machine Learning", "C/C++", "SQL"]] or ["Core Programming"],
                "missing": ["PyTorch / TensorFlow Deep Dive", "Hyperparameter Tuning (Optuna)", "Model Quantization & ONNX", "FastAPI Low-Latency Serving"],
                "tools": ["Python", "PyTorch", "Scikit-Learn", "FastAPI", "Docker", "Weights & Biases"],
                "projects": [
                    "Deep Learning Computer Vision Classifier: ResNet-based medical or agricultural diagnosis tool.",
                    "End-to-End Real Estate Price Prediction Pipeline with Automated Retraining."
                ],
                "roles": ["Associate ML Engineer", "AI/ML Developer", "Data Scientist - ML Focus"],
                "roadmaps": (
                    ["Linear Algebra, Calculus & Probability", "Advanced Scikit-Learn Pipelines", "PyTorch Tensors & Custom Datasets", "Building Simple Neural Networks"],
                    ["Convolutional & Recurrent Networks", "Transfer Learning & Fine-Tuning", "FastAPI Model Microservice", "Dockerizing Model Inference"],
                    ["Experiment Tracking (WandB)", "Edge Deployment / ONNX Conversion", "Comprehensive Capstone Portfolio on GitHub", "Algorithm & ML Coding Interviews"]
                )
            },
            {
                "title": "Data Engineer",
                "score": 86,
                "overview": "Architects high-performance pipelines that ingest, transform, and store vast amounts of raw data so ML models and analysts can consume clean data.",
                "why": [
                    "Data engineering is the indispensable backbone of all AI/ML initiatives.",
                    "High demand with less crowded candidate pools compared to pure research.",
                    "Offers tremendous software craftsmanship and distributed systems exposure."
                ],
                "existing": [s for s in tech_skills if s in ["SQL", "Python", "Java", "C/C++"]] or ["Logical Thinking"],
                "missing": ["Apache Spark / PySpark", "Workflow Orchestration (Airflow)", "Data Lakehouse Design (Delta Lake)", "Cloud Storage & Streaming (Kafka)"],
                "tools": ["Python", "SQL", "Apache Airflow", "PySpark", "PostgreSQL", "Docker"],
                "projects": [
                    "Automated Crypto & Stock Market Data Lake: Pipeline scraping exchange data every hour, transforming via PySpark, and loading to Postgres.",
                    "Airflow Directed Acyclic Graph (DAG) for Daily Automated Batch Processing."
                ],
                "roles": ["Junior Data Engineer", "Data Platform Associate", "ETL Developer"],
                "roadmaps": (
                    ["Advanced SQL & Indexing", "Python Data Manipulation & Generators", "PostgreSQL Administration & Schema Design", "Git & Linux Automation"],
                    ["Apache Spark Fundamentals with PySpark", "Data Warehouse vs Data Lake Architecture", "Orchestrating Pipelines with Airflow", "Dockerized Data Pipeline"],
                    ["Streaming Concepts with Kafka Basics", "Cloud Data Warehouse (Snowflake / BigQuery)", "End-to-End Portfolio Data Pipeline on GitHub", "Data Engineering System Design & SQL Interviews"]
                )
            }
        ]
    elif "Business Analyst" in goal or "Business and Management" in interests or "Commerce" in profile.get("degree_branch", ""):
        careers = [
            {
                "title": "Technical Business Analyst",
                "score": 93,
                "overview": "Acts as the strategic bridge between business stakeholders and software engineering teams, translating market needs into clear software requirements.",
                "why": [
                    "Directly capitalizes on your communication, leadership, and management strengths.",
                    "Does not require heavy low-level coding while keeping you at the heart of technology products.",
                    "Outstanding executive visibility and swift progression into Product Management."
                ],
                "existing": [s for s in tech_skills if s in ["SQL", "HTML/CSS", "Data Analysis"]] or ["Business & Stakeholder Communication"],
                "missing": ["Agile / Scrum Methodologies (Jira)", "User Story Mapping & BRD Writing", "Wireframing with Figma", "SQL for Business Reporting"],
                "tools": ["Jira & Confluence", "Figma", "SQL", "Power BI / Tableau", "Excel Advanced", "Miro"],
                "projects": [
                    "Fintech Mobile App Product Requirements Document (PRD): Full specification including user journeys, acceptance criteria, and Figma wireframes.",
                    "Customer Retention SQL Analysis: Extracting data to evaluate why customer drop-off occurred during checkout."
                ],
                "roles": ["Associate Business Analyst", "Product Analyst", "Functional Consultant"],
                "roadmaps": (
                    ["Software Development Lifecycle (SDLC) & Agile", "Writing User Stories & Acceptance Criteria", "Excel for Business Analytics", "SQL Basics (SELECT, WHERE, JOIN)"],
                    ["Business Process Modeling (BPMN)", "Jira Sprint Setup & Backlog Grooming", "Figma UI/UX Wireframing", "Conducting Stakeholder Requirement Interviews"],
                    ["Product Requirements Document (PRD) Capstone", "Tableau/Power BI Dashboarding", "Portfolio Case Study on Notion / GitHub", "BA Scenario-Based & Case Study Interview Prep"]
                )
            },
            {
                "title": "Associate Product Manager",
                "score": 88,
                "overview": "Guides the vision, execution, and launch of digital products, collaborating across engineering, design, marketing, and sales.",
                "why": [
                    "Exceptional match for entrepreneurial, communicative, and creative thinkers.",
                    "Puts you in the driver's seat of product strategy and user experience.",
                    "High prestige role in both tech startups and global technology conglomerates."
                ],
                "existing": [s for s in profile.get("strongest_skills", []) if s in ["Leadership", "Communication", "Creativity"]] or ["Strategic Mindset"],
                "missing": ["Product Discovery & User Research", "North Star Metrics & KPI Tracking", "A/B Testing Methodologies", "Tech Stack Fundamentals for PMs"],
                "tools": ["Notion", "Figma", "Mixpanel / Google Analytics", "Jira", "Trello"],
                "projects": [
                    "Product Teardown & Redesign Proposal: Comprehensive deck dissecting Spotify or Duolingo with proposed feature improvements.",
                    "Zero-to-One Product Launch Strategy: Market sizing, user persona interviews, and launch roadmap for a campus delivery app."
                ],
                "roles": ["Associate Product Manager (APM)", "Junior Product Owner", "Product Operations Associate"],
                "roadmaps": (
                    ["Product Thinking & Problem Validation", "User Persona Creation & Customer Discovery", "Competitor & Market Landscape Analysis", "Core Tech Architecture for Non-Engineers"],
                    ["Defining Product Metrics (HEART, Pirate Funnel)", "Wireframing & Prototyping in Figma", "Prioritization Frameworks (RICE, MoSCoW)", "Executing Sprint Plans with Jira"],
                    ["Comprehensive Product Teardown Portfolio", "A/B Test Design & Launch Strategy", "Product Case Interview Frameworks (CIRCLES)", "Behavioral & Product Sense Interview Practice"]
                )
            },
            {
                "title": "UI/UX & Product Designer",
                "score": 85,
                "overview": "Designs intuitive, beautiful, and accessible user interfaces and interactions for mobile apps and web platforms.",
                "why": [
                    "Combines your interest in creativity, design, and user psychology.",
                    "Fast feedback loop with immediate tangible visual outcomes.",
                    "High demand across tech startups and established design agencies."
                ],
                "existing": [s for s in tech_skills if s in ["HTML/CSS", "JavaScript"]] or ["Aesthetic & Creative Vision"],
                "missing": ["Figma Advanced Components & Auto-Layout", "Design Systems & Token Standards", "Usability Testing & User Interviews", "Responsive Web Design Principles"],
                "tools": ["Figma", "FigJam", "Webflow", "Adobe Creative Suite", "HTML/CSS"],
                "projects": [
                    "EduTech Learning Platform Mobile App: Complete Figma prototype with design system, dark mode, and interactive micro-animations.",
                    "SaaS Dashboard Redesign: Clean, modern analytics dashboard with high accessibility scores."
                ],
                "roles": ["Junior UI/UX Designer", "Product Design Intern", "Visual Designer"],
                "roadmaps": (
                    ["Design Fundamentals (Typography, Color, Spacing)", "Figma Interface & Vector Tools", "Wireframing & Low-Fidelity Layouts", "Heuristic Evaluation of Existing Apps"],
                    ["Auto-Layout, Components & Variants in Figma", "Building a Reusable Design System", "High-Fidelity Interactive Prototyping", "Conducting User Usability Tests"],
                    ["Case Study Documentation (Problem, Process, Solution)", "Portfolio Website Setup (Framer / Behance)", "Design Critique Presentations", "Design Challenge & Portfolio Walkthrough Interviews"]
                )
            }
        ]
    else:
        # Default: Full-Stack / Software Engineering Focus (e.g. CS Java / Web / General)
        careers = [
            {
                "title": "Full-Stack Web Developer",
                "score": 94,
                "overview": "Builds complete web applications from responsive front-end user interfaces to robust back-end server APIs and database models.",
                "why": [
                    f"Seamlessly builds on your foundation in {', '.join(tech_skills) if tech_skills else 'software programming'}.",
                    "The single largest job category in software engineering with immense hiring opportunities.",
                    "Allows you to quickly demonstrate working full-stack apps to recruiters and examiners."
                ],
                "existing": [s for s in tech_skills if s in ["Java", "Python", "JavaScript", "HTML/CSS", "React", "SQL", "Spring Boot"]] or ["Software Fundamentals"],
                "missing": ["RESTful API Architecture", "Modern React & State Management", "Relational Database ORM (Hibernate / SQLAlchemy / Prisma)", "Cloud Deployment & CI/CD"],
                "tools": ["JavaScript / TypeScript", "React", "Node.js or Spring Boot / FastAPI", "PostgreSQL", "Git", "Docker"],
                "projects": [
                    "Full-Stack Collaborative Task Manager: React front-end, REST API backend, JWT authentication, and PostgreSQL database.",
                    "Campus Placement Portal: Role-based access for students and recruiters with live resume review and status updates."
                ],
                "roles": ["Full-Stack Developer", "Software Development Engineer (SDE 1)", "Web Application Developer"],
                "roadmaps": (
                    ["HTML5, Modern CSS (Flexbox/Grid), TailwindCSS", "JavaScript ES6+ Core & DOM Manipulation", "Git Version Control & GitHub Workflows", "Building Responsive Static Web Applications"],
                    ["Modern React (Hooks, Components, Router)", "Backend API Development (Node/Express or Spring Boot)", "Database Design & SQL Queries", "Connecting Frontend to Backend REST Endpoints"],
                    ["User Authentication & Security (JWT, bcrypt)", "Full-Stack Capstone Project Deployment (Vercel + Render)", "Dockerizing the Application & README Polish", "Data Structures & Full-Stack System Design Interviews"]
                )
            },
            {
                "title": "Backend Software Engineer",
                "score": 90,
                "overview": "Focuses on high-performance server architectures, API security, caching mechanisms, database scalability, and business logic execution.",
                "why": [
                    "Ideal for students who enjoy algorithmic problem-solving and structured systems.",
                    "Deeply aligns with enterprise demand for Java, Spring Boot, or Python backend engineers.",
                    "Provides high compensation and great transition into distributed systems architecture."
                ],
                "existing": [s for s in tech_skills if s in ["Java", "Python", "C/C++", "SQL", "Spring Boot"]] or ["Algorithmic Problem Solving"],
                "missing": ["Microservices Architecture", "Caching with Redis", "Message Queues (RabbitMQ/Kafka)", "Unit Testing & Test-Driven Development (JUnit/PyTest)"],
                "tools": ["Java / Spring Boot or Python", "PostgreSQL", "Redis", "Docker", "Postman", "Git"],
                "projects": [
                    "High-Throughput E-Commerce Order Processing API with Redis caching and inventory locking.",
                    "Secure Authentication & Authorization Microservice with Role-Based Access Control (RBAC)."
                ],
                "roles": ["Backend Developer", "Junior Software Engineer", "API Specialist"],
                "roadmaps": (
                    ["Core Programming OOP Mastery & Clean Code", "Relational Database Schema Design & Normalization", "HTTP Protocol & REST API Fundamentals", "Postman API Testing & Environment Configuration"],
                    ["Building Production REST APIs with Framework of Choice", "Database ORM & Transaction Management", "Caching Strategies with Redis", "Writing Unit & Integration Tests"],
                    ["Containerization with Docker", "Microservices vs Monolith Architecture", "Deploying Backend Microservice to Cloud", "Backend Architecture & LeetCode Coding Interviews"]
                )
            },
            {
                "title": "Cloud & DevOps Associate",
                "score": 85,
                "overview": "Automates software delivery pipelines, manages cloud infrastructure, and guarantees 99.99% system availability and scalability.",
                "why": [
                    "Modern software companies prioritize automated CI/CD and cloud reliability above all else.",
                    "High starting demand with rapid salary increases as certifications accumulate.",
                    "Perfect synergy with modern containerization and scripting practices."
                ],
                "existing": [s for s in tech_skills if s in ["C/C++", "Python", "Java", "SQL"]] or ["Logical Systems Aptitude"],
                "missing": ["Linux Administration & Shell Scripting", "Docker & Kubernetes Basics", "CI/CD Pipelines (GitHub Actions)", "Cloud Basics (AWS EC2, S3, IAM)"],
                "tools": ["Linux (Ubuntu)", "Docker", "GitHub Actions", "AWS", "Terraform", "Nginx"],
                "projects": [
                    "Automated CI/CD Pipeline: GitHub Actions workflow that runs tests, builds Docker container, and deploys to cloud upon git push.",
                    "Multi-Tier Web App Hosting with Nginx Reverse Proxy and SSL Certificates."
                ],
                "roles": ["DevOps Engineer Intern", "Junior Cloud Engineer", "Site Reliability Associate"],
                "roadmaps": (
                    ["Linux Filesystem, Permissions & Bash Scripting", "Networking Fundamentals (DNS, HTTP/S, SSH)", "Git Branching Strategies", "Web Server Configuration (Nginx)"],
                    ["Docker Containers, Dockerfile & Docker Compose", "Continuous Integration with GitHub Actions", "Cloud Infrastructure (AWS EC2, S3, IAM)", "Automated Application Deployment"],
                    ["Infrastructure Monitoring & Logging Basics", "Intro to Kubernetes Cluster Concepts", "Open-Source DevOps Repository on GitHub", "DevOps & Cloud Technical Interview Practice"]
                )
            }
        ]

    # Build structured response adhering to schema
    formatted_recs = []
    for c in careers:
        rm1, rm2, rm3 = c["roadmaps"]
        formatted_recs.append({
            "career_title": c["title"],
            "suitability_score": c["score"],
            "career_overview": c["overview"],
            "why_suitable": c["why"],
            "existing_relevant_skills": c["existing"],
            "missing_skills": c["missing"],
            "tools_and_technologies": c["tools"],
            "suggested_projects": c["projects"],
            "job_roles": c["roles"],
            "roadmap": {
                "month_1": {
                    "title": "Foundation",
                    "weeks": [
                        {"week": 1, "topics": [rm1[0]], "tasks": ["Study core syntax & design rules", "Complete 5 guided practice coding exercises"], "outcome": f"Confident grasp of {rm1[0]}"},
                        {"week": 2, "topics": [rm1[1]], "tasks": ["Build foundational scripts", "Document concepts in personal notes"], "outcome": f"Proficiency in {rm1[1]}"},
                        {"week": 3, "topics": [rm1[2]], "tasks": ["Solve real-world diagnostic problems", "Set up local development tools"], "outcome": f"Mastery of {rm1[2]}"},
                        {"week": 4, "topics": [rm1[3]], "tasks": ["Month 1 Capstone milestone project", "Push clean code repository to GitHub"], "outcome": f"Completed foundation module with {rm1[3]}"}
                    ]
                },
                "month_2": {
                    "title": "Skill Development",
                    "weeks": [
                        {"week": 5, "topics": [rm2[0]], "tasks": ["Implement intermediate architectural patterns", "Optimize existing code for efficiency"], "outcome": f"Applied knowledge of {rm2[0]}"},
                        {"week": 6, "topics": [rm2[1]], "tasks": ["Integrate external APIs and libraries", "Handle edge cases and exceptions"], "outcome": f"Production readiness in {rm2[1]}"},
                        {"week": 7, "topics": [rm2[2]], "tasks": ["Design multi-tier integration", "Implement automated validation"], "outcome": f"Systematic execution of {rm2[2]}"},
                        {"week": 8, "topics": [rm2[3]], "tasks": ["Construct working mini-project", "Write comprehensive unit tests"], "outcome": "Fully functional, tested mini-project ready for demonstration"}
                    ]
                },
                "month_3": {
                    "title": "Practical Implementation",
                    "weeks": [
                        {"week": 9, "topics": [rm3[0]], "tasks": ["Kick off end-to-end capstone build", "Define system architecture and data schemas"], "outcome": f"Core framework operational for {rm3[0]}"},
                        {"week": 10, "topics": [rm3[1]], "tasks": ["Implement advanced features", "Write thorough documentation and API specs"], "outcome": f"Polished implementation with {rm3[1]}"},
                        {"week": 11, "topics": [rm3[2]], "tasks": ["Deploy live application to public cloud/server", "Record a 2-minute video walkthrough or demo"], "outcome": "Live public demo link and curated GitHub repository"},
                        {"week": 12, "topics": [rm3[3]], "tasks": ["Conduct mock technical interviews", "Tailor resume and optimize LinkedIn profile"], "outcome": "Job-ready interview confidence and portfolio presentation"}
                    ]
                }
            }
        })

    summary = (
        f"{name} presents a strong {exp} profile with a solid academic background in {profile.get('degree_branch', 'Technical studies')}. "
        f"With existing familiarity in {', '.join(tech_skills) if tech_skills else 'core problem-solving'} and a dedication of "
        f"{availability} daily, the student possesses high potential to transition into industry-ready roles over a structured 90-day trajectory."
    )

    overall = (
        f"For {name}, consistency over the next 90 days is the primary catalyst for career breakthrough. "
        f"Focus deeply on mastering one primary pathway first before branching out. Commit to your planned {availability} "
        f"of focused practice daily, publish every project to GitHub with clean documentation, and actively share your learning journey."
    )

    return {
        "profile_summary": summary,
        "career_recommendations": formatted_recs,
        "overall_recommendation": overall
    }


def generate_pdf_report(profile: dict, ai_data: dict) -> bytes:
    """
    Generates a beautifully styled, professional PDF career report using ReportLab.
    Returns bytes of the generated PDF document.
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=36,
        leftMargin=36,
        topMargin=36,
        bottomMargin=36,
    )

    styles = getSampleStyleSheet()

    # Custom Color Palette
    c_primary = colors.HexColor("#1E3A8A")     # Navy Blue
    c_secondary = colors.HexColor("#2563EB")   # Royal Blue
    c_accent = colors.HexColor("#4F46E5")      # Indigo
    c_dark = colors.HexColor("#0F172A")        # Dark Slate
    c_light_bg = colors.HexColor("#F8FAFC")    # Slate 50
    c_card_bg = colors.HexColor("#F0F7FF")     # Light Blue Tint
    c_border = colors.HexColor("#CBD5E1")      # Border Slate
    c_green = colors.HexColor("#059669")       # Emerald

    # Typography Styles
    title_style = ParagraphStyle(
        "DocTitle",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=20,
        leading=24,
        textColor=c_primary,
        alignment=0,
    )
    subtitle_style = ParagraphStyle(
        "DocSubtitle",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=10,
        leading=14,
        textColor=colors.HexColor("#64748B"),
    )
    badge_style = ParagraphStyle(
        "DocBadge",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8,
        leading=10,
        textColor=c_secondary,
    )
    h2_style = ParagraphStyle(
        "SectionH2",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=13,
        leading=17,
        textColor=c_primary,
        spaceBefore=10,
        spaceAfter=4,
    )
    h3_style = ParagraphStyle(
        "SectionH3",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=11,
        leading=14,
        textColor=c_secondary,
        spaceBefore=6,
        spaceAfter=2,
    )
    body_style = ParagraphStyle(
        "BodyDark",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=9,
        leading=13,
        textColor=c_dark,
    )
    bold_label = ParagraphStyle(
        "BoldLabel",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=9,
        leading=13,
        textColor=c_dark,
    )
    tag_green = ParagraphStyle(
        "TagGreen",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8,
        leading=11,
        textColor=c_green,
    )
    tag_blue = ParagraphStyle(
        "TagBlue",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8,
        leading=11,
        textColor=c_secondary,
    )

    story = []

    # 1. Header Banner
    header_data = [
        [
            Paragraph("<b>CAREER PATH ADVISOR</b>", title_style),
            Paragraph("<b>AI POWERED CAREER GUIDANCE | PROJECT 45</b><br/>Roll No: 45 | Generative AI", badge_style)
        ],
        [
            Paragraph("Discover your potential. Explore your possibilities. Build your future with AI.", subtitle_style),
            Paragraph(f"Generated: {datetime.now().strftime('%d %B %Y, %I:%M %p')}", subtitle_style)
        ]
    ]
    header_table = Table(header_data, colWidths=[360, 180])
    header_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('ALIGN', (1,0), (1,-1), 'RIGHT'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 2),
    ]))
    story.append(header_table)
    story.append(Spacer(1, 8))
    story.append(HRFlowable(width="100%", thickness=1.5, color=c_secondary, spaceAfter=10))

    # 2. Student Profile Summary Table
    story.append(Paragraph("1. Student Profile Overview", h2_style))
    student_name = profile.get("student_name", "Student")
    edu = profile.get("education_level", "N/A")
    branch = profile.get("degree_branch", "N/A")
    exp = profile.get("experience_level", "Beginner")
    hours = profile.get("daily_learning_availability", "2 Hours")
    goal = profile.get("career_goal", "Not Sure Yet")
    skills = ", ".join(profile.get("technical_skills", [])) or "None specified"
    interests = ", ".join(profile.get("personal_interests", [])) or "None specified"

    profile_table_data = [
        [Paragraph("<b>Student Name:</b>", bold_label), Paragraph(student_name, body_style),
         Paragraph("<b>Education:</b>", bold_label), Paragraph(f"{edu} ({branch})", body_style)],
        [Paragraph("<b>Experience Level:</b>", bold_label), Paragraph(exp, body_style),
         Paragraph("<b>Daily Availability:</b>", bold_label), Paragraph(hours, body_style)],
        [Paragraph("<b>Target Goal:</b>", bold_label), Paragraph(goal, body_style),
         Paragraph("<b>Working Style:</b>", bold_label), Paragraph(profile.get("preferred_working_style", "Both"), body_style)],
        [Paragraph("<b>Technical Skills:</b>", bold_label), Paragraph(skills, body_style),
         Paragraph("<b>Key Interests:</b>", bold_label), Paragraph(interests, body_style)],
    ]
    p_table = Table(profile_table_data, colWidths=[100, 170, 100, 170])
    p_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), c_light_bg),
        ('GRID', (0, 0), (-1, -1), 0.5, c_border),
        ('PADDING', (0, 0), (-1, -1), 5),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]))
    story.append(p_table)
    story.append(Spacer(1, 6))

    # Profile Summary Narrative
    summary_text = ai_data.get("profile_summary", "")
    if summary_text:
        story.append(Paragraph(f"<b>Profile Analysis:</b> {summary_text}", body_style))
        story.append(Spacer(1, 8))

    # 3. Top 3 Career Recommendations
    story.append(Paragraph("2. Top 3 Personalized Career Recommendations", h2_style))
    recs = ai_data.get("career_recommendations", [])

    for i, rec in enumerate(recs, start=1):
        c_title = rec.get("career_title", f"Career {i}")
        c_score = rec.get("suitability_score", 85)
        c_overview = rec.get("career_overview", "")
        why_list = rec.get("why_suitable", [])
        existing_skills = ", ".join(rec.get("existing_relevant_skills", [])) or "None listed"
        missing_skills = ", ".join(rec.get("missing_skills", [])) or "None listed"
        tools = ", ".join(rec.get("tools_and_technologies", [])) or "Standard tools"
        roles = ", ".join(rec.get("job_roles", [])) or "Industry Roles"

        card_content = [
            [
                Paragraph(f"<b>Option #{i}: {c_title}</b>", h3_style),
                Paragraph(f"<b>Suitability Score: {c_score}%</b>", tag_blue)
            ],
            [
                Paragraph(f"<b>Overview:</b> {c_overview}", body_style),
                Paragraph(f"<b>Target Roles:</b> {roles}", body_style)
            ],
            [
                Paragraph(f"<b>Matching Skills:</b> <font color='#059669'>{existing_skills}</font>", body_style),
                Paragraph(f"<b>Missing Skills (To Learn):</b> <font color='#D97706'>{missing_skills}</font>", body_style)
            ],
            [
                Paragraph(f"<b>Key Technologies:</b> {tools}", body_style),
                Paragraph(f"<b>Key Advantage:</b> {why_list[0] if why_list else 'High suitability'}", body_style)
            ]
        ]
        rec_table = Table(card_content, colWidths=[330, 210])
        rec_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), c_card_bg if i == 1 else c_light_bg),
            ('BOX', (0, 0), (-1, -1), 1, c_secondary if i == 1 else c_border),
            ('PADDING', (0, 0), (-1, -1), 5),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        story.append(rec_table)
        story.append(Spacer(1, 6))

    # 4. Detailed 3-Month Learning Roadmap (for the #1 recommended career)
    if recs:
        top_rec = recs[0]
        story.append(Spacer(1, 4))
        story.append(Paragraph(f"3. 3-Month Actionable Learning Roadmap ({top_rec.get('career_title')})", h2_style))

        roadmap = top_rec.get("roadmap", {})
        for m_key, m_label in [("month_1", "Month 1 - Foundation"), ("month_2", "Month 2 - Skill Development"), ("month_3", "Month 3 - Practical Implementation")]:
            m_obj = roadmap.get(m_key, {})
            weeks = m_obj.get("weeks", [])
            story.append(Paragraph(f"<b>{m_label}</b>", h3_style))

            table_rows = [
                [Paragraph("<b>Week</b>", bold_label), Paragraph("<b>Topics to Learn</b>", bold_label), Paragraph("<b>Practical Tasks & Exercises</b>", bold_label), Paragraph("<b>Measurable Outcome</b>", bold_label)]
            ]
            for w in weeks:
                w_num = str(w.get("week", ""))
                topics = "<br/>• ".join(w.get("topics", []))
                if topics:
                    topics = "• " + topics
                tasks = "<br/>• ".join(w.get("tasks", []))
                if tasks:
                    tasks = "• " + tasks
                outcome = w.get("outcome", "")

                table_rows.append([
                    Paragraph(f"Wk {w_num}", bold_label),
                    Paragraph(topics or "Core concepts", body_style),
                    Paragraph(tasks or "Hands-on exercises", body_style),
                    Paragraph(outcome or "Milestone verified", body_style),
                ])

            rm_table = Table(table_rows, colWidths=[40, 160, 180, 160])
            rm_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), c_light_bg),
                ('GRID', (0, 0), (-1, -1), 0.5, c_border),
                ('PADDING', (0, 0), (-1, -1), 4),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ]))
            story.append(rm_table)
            story.append(Spacer(1, 6))

    # 5. Overall Guidance & Closing Advice
    story.append(Spacer(1, 4))
    story.append(Paragraph("4. Career Guidance & Strategic Next Steps", h2_style))
    overall_advice = ai_data.get("overall_recommendation", "")
    story.append(Paragraph(overall_advice, body_style))
    story.append(Spacer(1, 8))

    # Disclaimer Footer
    disclaimer = (
        "<b>Evaluation & Academic Disclaimer:</b> This report was generated using Google Gemini LLM API as part of "
        "College Practical Project 45. All learning roadmaps and skill assessments are advisory and adapted to the student's input profile. "
        "No employment, salary, or corporate placement is guaranteed."
    )
    story.append(HRFlowable(width="100%", thickness=0.8, color=c_border, spaceBefore=6, spaceAfter=6))
    story.append(Paragraph(disclaimer, ParagraphStyle("Disc", parent=styles["Normal"], fontSize=7, leading=10, textColor=colors.HexColor("#64748B"))))

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()
