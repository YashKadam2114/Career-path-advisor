"""
test_app.py
-----------
Comprehensive automated test suite for Career Path Advisor.
Validates input checking, JSON schema parsing, 5 student profile test cases,
roadmap generation, and ReportLab PDF document compilation.
"""

import os
import sys

# Ensure local module imports work
sys.path.insert(0, os.path.dirname(__file__))

from utils import (
    validate_inputs,
    parse_json_response,
    generate_fallback_response,
    generate_pdf_report,
    get_sample_profiles,
)
from prompt import build_user_prompt, SYSTEM_PROMPT
from ai_service import analyze_career_profile


def test_input_validation():
    print("Testing Input Validation...")
    # 1. Valid profile
    valid_profile = {
        "student_name": "Kavya Nair",
        "education_level": "Undergraduate",
        "degree_branch": "Computer Science",
        "technical_skills": ["Python", "SQL"],
    }
    is_valid, errs = validate_inputs(valid_profile)
    assert is_valid, f"Expected valid profile, got errors: {errs}"

    # 2. Missing student name
    invalid_profile_1 = {
        "student_name": "  ",
        "education_level": "Undergraduate",
        "degree_branch": "Computer Science",
    }
    is_valid, errs = validate_inputs(invalid_profile_1)
    assert not is_valid
    assert any("Student Name is required" in e for e in errs)

    # 3. Missing skills and subjects
    invalid_profile_2 = {
        "student_name": "Kavya Nair",
        "education_level": "Undergraduate",
        "degree_branch": "Computer Science",
        "technical_skills": [],
        "favourite_subjects": [],
        "personal_interests": [],
    }
    is_valid, errs = validate_inputs(invalid_profile_2)
    assert not is_valid
    assert any("at least one" in e for e in errs)

    print("[OK] Input Validation: PASSED")


def test_json_parsing():
    print("Testing JSON Response Parsing...")
    raw_markdown = """
```json
{
  "profile_summary": "Strong analytical and algorithmic baseline.",
  "career_recommendations": [
    {
      "career_title": "Full-Stack Web Developer",
      "suitability_score": 94,
      "career_overview": "Builds end-to-end cloud web applications.",
      "why_suitable": ["High command over JavaScript and databases"],
      "existing_relevant_skills": ["JavaScript", "SQL"],
      "missing_skills": ["Docker", "GraphQL"],
      "tools_and_technologies": ["React", "Node.js", "PostgreSQL"],
      "suggested_projects": ["Collaborative Workspace Platform"],
      "job_roles": ["Full-Stack Engineer", "Frontend Specialist"],
      "roadmap": {
        "month_1": {
          "title": "Foundation",
          "weeks": [
            {
              "week": 1,
              "topics": ["HTML5/CSS3", "DOM API"],
              "tasks": ["Build responsive landing page"],
              "outcome": "Proficient in modern DOM design"
            }
          ]
        },
        "month_2": {
          "title": "Skill Development",
          "weeks": [
            {
              "week": 5,
              "topics": ["React Hooks"],
              "tasks": ["State management"],
              "outcome": "Single Page App"
            }
          ]
        },
        "month_3": {
          "title": "Practical Implementation",
          "weeks": [
            {
              "week": 9,
              "topics": ["Deployment"],
              "tasks": ["Deploy to Cloud"],
              "outcome": "Live Application"
            }
          ]
        }
      }
    }
  ],
  "overall_recommendation": "Maintain daily focus on building deployable projects."
}
```
"""
    parsed = parse_json_response(raw_markdown)
    assert parsed["profile_summary"] == "Strong analytical and algorithmic baseline."
    assert len(parsed["career_recommendations"]) == 1
    assert parsed["career_recommendations"][0]["suitability_score"] == 94
    assert parsed["career_recommendations"][0]["career_title"] == "Full-Stack Web Developer"

    print("[OK] JSON Response Parsing: PASSED")


def test_five_sample_profiles():
    print("Testing All 5 Student Test Profiles...")
    profiles = get_sample_profiles()
    assert len(profiles) == 5, f"Expected 5 sample profiles, got {len(profiles)}"

    for title, profile in profiles.items():
        print(f"\nVerifying Profile: {title}")

        # Check prompt generation
        prompt = build_user_prompt(profile)
        assert profile["student_name"] in prompt
        assert "STRICT JSON OUTPUT REQUIREMENT" in prompt

        # Check AI analysis execution (fallback/demo mode verified)
        result, is_live, msg = analyze_career_profile(
            profile, api_key=None, allow_simulation_fallback=True
        )

        # Requirement 1: Exactly 3 career recommendations
        recs = result.get("career_recommendations", [])
        assert len(recs) == 3, f"Expected exactly 3 recommendations for {title}, got {len(recs)}"

        # Requirement 2: Profile summary and overall guidance
        assert "profile_summary" in result and len(result["profile_summary"]) > 20
        assert "overall_recommendation" in result and len(result["overall_recommendation"]) > 20

        # Requirement 3: Detailed 3-month roadmap for every career
        for i, rec in enumerate(recs, start=1):
            assert "career_title" in rec and len(rec["career_title"]) > 0
            assert "suitability_score" in rec and 50 <= rec["suitability_score"] <= 100
            assert "why_suitable" in rec and len(rec["why_suitable"]) > 0
            assert "existing_relevant_skills" in rec
            assert "missing_skills" in rec and len(rec["missing_skills"]) > 0
            assert "tools_and_technologies" in rec and len(rec["tools_and_technologies"]) > 0
            assert "job_roles" in rec and len(rec["job_roles"]) > 0

            roadmap = rec.get("roadmap", {})
            assert "month_1" in roadmap, f"Missing month_1 for {rec['career_title']}"
            assert "month_2" in roadmap, f"Missing month_2 for {rec['career_title']}"
            assert "month_3" in roadmap, f"Missing month_3 for {rec['career_title']}"

            for m_key in ["month_1", "month_2", "month_3"]:
                weeks = roadmap[m_key].get("weeks", [])
                assert len(weeks) >= 1, f"Missing weeks in {m_key} for {rec['career_title']}"
                for w in weeks:
                    assert "week" in w
                    assert "topics" in w
                    assert "tasks" in w
                    assert "outcome" in w

        # Requirement 4: ReportLab PDF Generation
        pdf_bytes = generate_pdf_report(profile, result)
        assert isinstance(pdf_bytes, bytes)
        assert len(pdf_bytes) > 2000, f"Generated PDF for {title} was unexpectedly small ({len(pdf_bytes)} bytes)"
        print(f"  -> Generated PDF size: {len(pdf_bytes)} bytes")

    print("\n[OK] All 5 Profiles Verified Successfully!")


if __name__ == "__main__":
    print("=" * 60)
    print("CAREER PATH ADVISOR - TEST SUITE")
    print("Roll Number: 45 | Problem Statement: 45")
    print("=" * 60)
    test_input_validation()
    test_json_parsing()
    test_five_sample_profiles()
    print("=" * 60)
    print("ALL TESTS COMPLETED SUCCESSFULLY! (100% PASS)")
    print("=" * 60)
