# Career Path Advisor – AI-Powered Career Guidance System

> **AI POWERED CAREER GUIDANCE | PROJECT 45**  
> **Student Roll Number:** 45  
> **Problem Statement Number:** 45  
> **Project Category:** Generative AI / Large Language Model (LLM)  
> **Programming Language:** Python 3.11+  

---

## 1. Project Overview

**Career Path Advisor** is a modern, interactive, and intelligent web application built using **Python**, **Streamlit**, and the **Google Gemini API** (`google-genai` SDK). It guides engineering, diploma, and college students in discovering high-compatibility career pathways tailored to their individual academic interests, programming competencies, soft skills, preferred working styles, and daily learning bandwidth.

Unlike traditional rule-based recommendation algorithms or static questionnaire tools, Career Path Advisor utilizes real-time Large Language Model (LLM) reasoning to synthesize user profiles into:
1. **Three personalized career recommendations** with dynamic suitability match scores.
2. **Granular skill gap analyses** separating possessed strengths from critical missing tools.
3. **Structured 90-day (3-month) learning roadmaps** with weekly goals, practical projects, and measurable milestones.
4. **Downloadable professional PDF career reports** for offline evaluation and student portfolio documentation.

---

## 2. Problem Statement & Objectives

### Problem Statement (Number 45)
Students and early-career graduates face information overload when choosing tech careers. Fast-shifting industry demands, hundreds of software frameworks, and varying personal aptitudes make standard static career charts ineffective. Students lack structured, personalized step-by-step guidance on how to bridge their current academic background with real-world industry requirements.

### Objectives
- **Dynamically evaluate** multi-dimensional student profiles using the Google Gemini LLM.
- **Generate exactly three realistic career recommendations** tailored to the student's current proficiency level (Beginner, Intermediate, Advanced).
- **Provide clear skill gap breakdowns** highlighting existing skills, missing skills, and required technology stacks.
- **Formulate a realistic 3-month action plan** divided into Month 1 (Foundation), Month 2 (Skill Development), and Month 3 (Practical Implementation) adapted to the student's daily study availability (1 to 4+ hours).
- **Export comprehensive, publication-quality PDF career dossiers** using ReportLab.
- **Provide robust fallback and error handling** ensuring zero downtime during college practical examinations and viva demonstrations.

---

## 3. Technology Stack

| Layer | Technology | Purpose |
|---|---|---|
| **Programming Language** | Python 3.11+ | Core application logic and data pipelines |
| **User Interface** | Streamlit | Responsive, modern, interactive web dashboard |
| **Generative AI** | Google Gemini API (`gemini-2.5-flash` / `gemini-1.5-flash`) | Deep profile reasoning and roadmap synthesis |
| **AI SDK** | `google-genai` | Modern official Google GenAI Python SDK |
| **Environment Management** | `python-dotenv` | Secure storage and loading of API credentials |
| **Data Handling** | `pandas` | Structured tabular comparisons and data transformation |
| **PDF Generation** | `reportlab` | Vector-rendered multi-page PDF career reports |
| **Image Processing** | `pillow` (PIL) | Dynamic asset loading and branding generation |

---

## 4. Key Features

- **Executive Landing Page:** Clean hero section with feature cards, interactive workflow overview, and intuitive navigation.
- **12-Point Comprehensive Assessment Questionnaire:**
  1. Student Name
  2. Education Level (Undergraduate, Postgraduate, Diploma, Other)
  3. Degree / Branch (Computer Science, IT, Electronics, Mechanical, Civil, Commerce, Arts, Other)
  4. Favourite Academic Subjects (Multi-select)
  5. Technical Skills (Multi-select)
  6. Personal Interests (Multi-select)
  7. Strongest Personal / Soft Skills (Multi-select)
  8. Preferred Working Style (Individual, Team, Both)
  9. Career Goal / Dream Role
  10. Technical Experience Level (Beginner, Intermediate, Advanced)
  11. Daily Learning Availability (1 Hour, 2 Hours, 3 Hours, 4+ Hours)
  12. Additional Ambitions / Constraints (Free-form text)
- **5 Pre-Configured Test Profiles:** 1-click loading for instant demonstration during college practical exams.
- **Suitability Match Metrics:** Visual percentage score and gradient progress indicators.
- **Side-by-Side Career Comparison Matrix:** Interactive tabular comparison across all three recommended options.
- **Deep-Dive 3-Month Action Roadmap:** Tabbed view of Month 1 (Foundation), Month 2 (Skill Development), and Month 3 (Practical Implementation) with weekly topics, tasks, and measurable outcomes.
- **Dedicated Skill Gap Analysis:** Categorized pills for verified skills, missing skills, and priority tech stacks.
- **One-Click PDF Export:** Generates an official, styled PDF report containing profile summary, recommendations, gap analysis, and roadmap.
- **Resilient Offline / Demo Simulation Mode:** Ensures the app never crashes during an evaluation even if internet connectivity drops or API quotas are exhausted.

---

## 5. System Architecture & Project Structure

### Architecture Flowchart

```
[ Student Input Form / 5 Sample Profiles ]
                   │
                   ▼
       [ Input Validation (utils.py) ]
                   │
                   ▼
     [ Prompt Construction (prompt.py) ]
                   │
                   ▼
     [ Gemini LLM API (ai_service.py) ] ── (Fallback Mode if Offline / No Key)
                   │
                   ▼
       [ JSON Parsing & Sanitization ]
                   │
        ┌──────────┴──────────┐
        ▼                     ▼
[ Streamlit UI Dashboard ]  [ ReportLab PDF Generator ]
(app.py)                   (utils.py)
```

### Complete Project File Structure

```
career-path-advisor/
│
├── app.py              # Main Streamlit user interface and state management
├── ai_service.py       # Google Gemini API integration and error handling
├── prompt.py           # System prompt and dynamic structured user prompt
├── utils.py            # Input validation, JSON parsing, PDF export, sample profiles
├── requirements.txt    # Project dependencies
├── .env                # Secret API key (ignored by git)
├── .env.example        # Template for environment configuration
├── .gitignore          # Excludes .env, __pycache__, and temporary files
├── README.md           # Comprehensive project documentation
│
└── assets/
    └── logo.png        # Application branding logo
```

---

## 6. Installation & Setup Guide

### Prerequisites
- Python 3.11 or higher installed.
- Windows PowerShell, macOS Terminal, or Linux Bash.
- Google Gemini API key (free tier available at [Google AI Studio](https://aistudio.google.com/app/apikey)).

### Step 1: Navigate to the Project Directory
Open Windows PowerShell and navigate to the `career-path-advisor` folder:
```powershell
cd career-path-advisor
```

### Step 2: Create and Activate a Virtual Environment (Recommended)
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### Step 3: Install Required Dependencies
```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### Step 4: Configure the Gemini API Key
1. Copy the example environment file:
   ```powershell
   Copy-Item .env.example .env
   ```
2. Open `.env` in any text editor and add your API key:
   ```env
   GEMINI_API_KEY=AIzaSyYourActualGeminiApiKeyHere
   ```
*(Note: You can also enter or paste your API key directly in the application's sidebar interface).*

---

## 7. How to Run the Application

Execute the following command in your terminal:
```powershell
streamlit run app.py
```

The application will start immediately and automatically open in your default browser at:
```
http://localhost:8501
```

---

## 8. Verification & Viva Test Cases

To verify that the application satisfies all requirements, five pre-configured student test profiles are embedded in the sidebar dropdown:

| Test Profile | Primary Interests & Skills | Expected Primary Recommendation | Verified Behavior |
|---|---|---|---|
| **1. CS Java & Software Dev** | Java, Spring Boot, SQL, Software Development | Full-Stack Web Developer / Backend SDE | Exactly 3 recommendations, 12-week roadmap, PDF export |
| **2. Python & Math (Data Science)** | Python, SQL, Data Analysis, Mathematics | Data Scientist / Data Analyst | 3 tailored options, statistical gap analysis, PDF export |
| **3. AI & Deep Learning Enthusiast** | Python, Machine Learning, Deep Learning, C++ | AI / Generative AI Solutions Engineer | High-suitability match, MLOps roadmap, PDF export |
| **4. Cybersecurity & Networking** | C/C++, Python, Linux, Security Protocols | Cybersecurity Analyst / SOC Analyst | Dedicated lab tasks, Security+ roadmap, PDF export |
| **5. Undecided / Non-Tech Beginner** | Commerce, Business, HTML/CSS, Leadership | Technical Business Analyst / Product Manager | Non-code heavy roadmap, Figma/Agile tasks, PDF export |

---

## 9. How to Push the Project to GitHub

To submit or showcase your project on GitHub:

```powershell
# 1. Initialize git repository (if not already initialized)
git init

# 2. Verify .gitignore is protecting sensitive keys
git status

# 3. Stage all files
git add .

# 4. Commit changes
git commit -m "Complete Career Path Advisor - AI-Powered Career Guidance System (Project 45)"

# 5. Add your remote GitHub repository
git remote add origin https://github.com/your-username/career-path-advisor.git

# 6. Push to main branch
git branch -M main
git push -u origin main
```

---

## 10. Future Enhancements

- **Interactive Resume Parser:** Allow students to upload a PDF resume for automated profile pre-filling.
- **Real-Time Job Market Scraping:** Integration with live job APIs (LinkedIn, Indeed) to show active openings for recommended roles.
- **GitHub Repository Analysis:** Automatically audit a student's public GitHub repositories to assess coding proficiency.
- **Mentor Connect:** Enable students to book 1-on-1 advisory sessions with verified industry seniors.

---

## 11. Student Credentials & Submission Note

- **Roll Number:** 45  
- **Problem Statement Number:** 45  
- **Project Name:** Career Path Advisor  
- **Category:** Generative AI / Large Language Model (LLM)  
- **Evaluation Criteria:** 10-Mark Practical Examination & Viva Voce Ready  
