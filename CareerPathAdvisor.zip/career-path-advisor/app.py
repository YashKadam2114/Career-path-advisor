"""
app.py
------
Career Path Advisor - Modern AI-Powered Career Guidance System
Student Roll No: 45 | Problem Statement: 45
Built with Streamlit, Google Gemini API (google-genai SDK), and ReportLab.
"""

import os
import streamlit as st
import pandas as pd
from dotenv import load_dotenv

from prompt import SYSTEM_PROMPT
from ai_service import analyze_career_profile, verify_api_key, get_api_key
from utils import (
    validate_inputs,
    get_sample_profiles,
    generate_pdf_report,
)

# Load environment variables
load_dotenv()

# --- Page Configuration ---
st.set_page_config(
    page_title="Career Path Advisor | Project 45",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)

# --- Custom Styling (Clean White + Light Blue + Subtle Purple Accents) ---
CUSTOM_CSS = """
<style>
/* Global Styling */
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

html, body, [class*="css"] {
    font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
    color: #1E293B;
}

/* Background Clean Palette */
.stApp {
    background: linear-gradient(180deg, #F8FAFC 0%, #FFFFFF 100%);
}

/* Header Badge & Hero */
.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: #EEF2FF;
    color: #4F46E5;
    border: 1px solid #C7D2FE;
    padding: 6px 14px;
    border-radius: 9999px;
    font-size: 0.78rem;
    font-weight: 700;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    margin-bottom: 12px;
}

.hero-title {
    font-size: 2.5rem;
    font-weight: 800;
    color: #0F172A;
    letter-spacing: -0.02em;
    line-height: 1.15;
    margin-bottom: 8px;
}

.hero-title span {
    background: linear-gradient(135deg, #2563EB 0%, #4F46E5 50%, #7C3AED 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.hero-subtitle {
    font-size: 1.1rem;
    color: #475569;
    margin-bottom: 24px;
    line-height: 1.5;
}

/* Card Styling */
.advisor-card {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 16px;
    padding: 24px;
    box-shadow: 0 4px 20px -2px rgba(99, 102, 241, 0.06);
    transition: all 0.25s ease-in-out;
    margin-bottom: 20px;
}

.advisor-card:hover {
    border-color: #C7D2FE;
    box-shadow: 0 10px 28px -4px rgba(79, 70, 229, 0.12);
    transform: translateY(-2px);
}

.card-feature {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 16px;
    padding: 22px;
    height: 100%;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.03);
    transition: all 0.2s ease;
}

.card-feature:hover {
    border-color: #93C5FD;
    box-shadow: 0 8px 24px rgba(37, 99, 235, 0.1);
    transform: translateY(-3px);
}

.feature-icon-box {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.4rem;
    margin-bottom: 14px;
}

.bg-blue-tint { background: #EFF6FF; color: #2563EB; }
.bg-purple-tint { background: #F5F3FF; color: #7C3AED; }
.bg-cyan-tint { background: #ECFEFF; color: #0891B2; }

/* Tag Pills */
.tag-pill {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 0.78rem;
    font-weight: 600;
    margin: 3px 4px 3px 0;
}

.tag-match {
    background: #ECFDF5;
    color: #059669;
    border: 1px solid #A7F3D0;
}

.tag-missing {
    background: #FFFBEB;
    color: #D97706;
    border: 1px solid #FDE68A;
}

.tag-tool {
    background: #EFF6FF;
    color: #2563EB;
    border: 1px solid #BFDBFE;
}

.tag-role {
    background: #F5F3FF;
    color: #6D28D9;
    border: 1px solid #DDD6FE;
}

/* Suitability Score Header */
.score-badge {
    font-size: 1.5rem;
    font-weight: 800;
    color: #2563EB;
}

/* Roadmap timeline */
.week-box {
    background: #F8FAFC;
    border: 1px solid #E2E8F0;
    border-left: 4px solid #4F46E5;
    border-radius: 8px;
    padding: 12px 16px;
    margin-bottom: 12px;
}

.week-title {
    font-weight: 700;
    font-size: 0.95rem;
    color: #1E293B;
    margin-bottom: 6px;
}

/* Sidebar info box */
.sidebar-info {
    background: #F0F7FF;
    border: 1px solid #BFDBFE;
    border-radius: 12px;
    padding: 14px;
    font-size: 0.85rem;
    color: #1E3A8A;
    margin-bottom: 16px;
}

/* Button overrides for Streamlit */
div.stButton > button:first-child {
    border-radius: 10px;
    font-weight: 600;
    letter-spacing: 0.01em;
    padding: 10px 24px;
    transition: all 0.2s ease-in-out;
}

/* Clean input labels */
label {
    font-weight: 600 !important;
    color: #1E293B !important;
}
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)

# --- Session State Initialization ---
if "current_view" not in st.session_state:
    st.session_state.current_view = "home"

if "analysis_result" not in st.session_state:
    st.session_state.analysis_result = None

if "student_profile" not in st.session_state:
    st.session_state.student_profile = {}

if "selected_career_idx" not in st.session_state:
    st.session_state.selected_career_idx = 0

if "api_message" not in st.session_state:
    st.session_state.api_message = ""

# Form state storage for pre-filling with sample profiles
if "form_data" not in st.session_state:
    st.session_state.form_data = {
        "student_name": "",
        "education_level": "Undergraduate",
        "degree_branch": "Computer Science",
        "favourite_subjects": ["Programming", "Database Management"],
        "technical_skills": ["Python", "SQL"],
        "personal_interests": ["Software Development", "Problem Solving"],
        "strongest_skills": ["Problem Solving", "Logical Thinking"],
        "preferred_working_style": "Both",
        "career_goal": "Software Developer",
        "experience_level": "Beginner",
        "daily_learning_availability": "2 Hours",
        "additional_info": "",
    }


def navigate_to(view_name: str):
    """Callback to switch top-level view."""
    st.session_state.current_view = view_name


def reset_assessment():
    """Resets the assessment form and cached results."""
    st.session_state.analysis_result = None
    st.session_state.selected_career_idx = 0
    st.session_state.api_message = ""
    st.session_state.form_data = {
        "student_name": "",
        "education_level": "Undergraduate",
        "degree_branch": "Computer Science",
        "favourite_subjects": [],
        "technical_skills": [],
        "personal_interests": [],
        "strongest_skills": [],
        "preferred_working_style": "Both",
        "career_goal": "Not Sure Yet",
        "experience_level": "Beginner",
        "daily_learning_availability": "2 Hours",
        "additional_info": "",
    }
    st.session_state.current_view = "assessment"


# --- SIDEBAR CONFIGURATION ---
with st.sidebar:
    # Project Logo & Credentials
    logo_path = os.path.join(os.path.dirname(__file__), "assets", "logo.png")
    if os.path.exists(logo_path):
        st.image(logo_path, width=120)

    st.markdown("### 🎓 Career Path Advisor")
    st.markdown(
        """
        <div class="sidebar-info">
            <b>Roll Number:</b> 45<br/>
            <b>Problem Statement:</b> 45<br/>
            <b>Domain:</b> Generative AI / LLM<br/>
            <b>SDK:</b> google-genai
        </div>
        """,
        unsafe_allow_html=True,
    )

    # API Key Management
    st.markdown("#### 🔑 Gemini API Settings")
    env_key = os.getenv("GEMINI_API_KEY", "")
    api_key_input = st.text_input(
        "Enter Gemini API Key",
        value=env_key,
        type="password",
        help="Reads automatically from .env if present. You can also paste your Google AI Studio API key here.",
    )

    if api_key_input:
        if st.button("Verify API Key", use_container_width=True):
            with st.spinner("Testing API connection..."):
                is_valid, msg = verify_api_key(api_key_input)
                if is_valid:
                    st.success("API Key is active & connected!")
                else:
                    st.error(f"Validation failed: {msg}")
    else:
        st.info("💡 No API key? A demo simulation mode is built-in for offline college evaluations!")

    st.markdown("---")

    # Sample Profile Quick-Loader (For Examination Demonstrations)
    st.markdown("#### ⚡ Quick Demo Profiles")
    st.caption("Load pre-configured student test profiles in 1 click:")
    sample_profiles = get_sample_profiles()
    sample_choice = st.selectbox(
        "Choose a Test Profile:",
        options=["Select a sample profile..."] + list(sample_profiles.keys()),
        index=0,
    )

    if sample_choice != "Select a sample profile...":
        if st.button("Load Selected Profile", use_container_width=True):
            selected_sample = sample_profiles[sample_choice]
            st.session_state.form_data = selected_sample.copy()
            st.session_state.current_view = "assessment"
            st.rerun()

    st.markdown("---")

    # Global Navigation Buttons
    st.markdown("#### 🧭 Quick Navigation")
    c1, c2 = st.columns(2)
    with c1:
        if st.button("🏠 Home", use_container_width=True):
            navigate_to("home")
            st.rerun()
    with c2:
        if st.button("📝 Form", use_container_width=True):
            navigate_to("assessment")
            st.rerun()

    if st.session_state.analysis_result is not None:
        if st.button("📊 View Results", use_container_width=True):
            navigate_to("results")
            st.rerun()

    if st.button("🔄 Reset Assessment", use_container_width=True):
        reset_assessment()
        st.rerun()


# ==============================================================================
# SECTION A: HOME / INTRODUCTION LANDING
# ==============================================================================
if st.session_state.current_view == "home":
    st.markdown(
        """
        <div class="hero-badge">
            ✨ AI POWERED CAREER GUIDANCE | PROJECT 45
        </div>
        <div class="hero-title">
            Career Path <span>Advisor</span>
        </div>
        <div class="hero-subtitle">
            Discover your potential. Explore your possibilities. Build your future with AI.
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Hero Banner Card
    st.markdown(
        """
        <div class="advisor-card" style="background: linear-gradient(135deg, #F0F7FF 0%, #FFFFFF 100%); border-left: 6px solid #2563EB;">
            <h3 style="margin-top:0; color: #1E3A8A;">Empowering Students with Intelligent LLM-Driven Direction</h3>
            <p style="color: #475569; font-size: 1.02rem; line-height: 1.6;">
                Navigating modern tech careers can be overwhelming with hundreds of evolving frameworks, emerging AI tools, and conflicting advice.
                <b>Career Path Advisor</b> evaluates your genuine passions, favourite academic coursework, technical competencies, and daily study availability
                using Google's <b>Gemini Large Language Model</b>. In seconds, you receive three tailored career pathways, clear skill-gap breakdowns,
                and an actionable, week-by-week 90-day learning curriculum.
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Feature Cards Section
    st.markdown("### 🚀 Core Capabilities")
    f_col1, f_col2, f_col3 = st.columns(3)

    with f_col1:
        st.markdown(
            """
            <div class="card-feature">
                <div class="feature-icon-box bg-blue-tint">🎯</div>
                <h4 style="margin: 0 0 8px 0; color: #1E293B;">1. Personalised Recommendations</h4>
                <p style="color: #64748B; font-size: 0.9rem; line-height: 1.5;">
                    Dynamically generates <b>three distinct, high-suitability career options</b> tailored to your exact profile,
                    complete with suitability scores and market context.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with f_col2:
        st.markdown(
            """
            <div class="card-feature">
                <div class="feature-icon-box bg-purple-tint">🔍</div>
                <h4 style="margin: 0 0 8px 0; color: #1E293B;">2. Skill Gap Analysis</h4>
                <p style="color: #64748B; font-size: 0.9rem; line-height: 1.5;">
                    Visualises the exact bridge between the skills you already master and the essential industry tools
                    you need to acquire next.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with f_col3:
        st.markdown(
            """
            <div class="card-feature">
                <div class="feature-icon-box bg-cyan-tint">📅</div>
                <h4 style="margin: 0 0 8px 0; color: #1E293B;">3. 3-Month Action Roadmap</h4>
                <p style="color: #64748B; font-size: 0.9rem; line-height: 1.5;">
                    Structured into Foundation, Skill Development, and Practical Implementation phases with weekly
                    goals, projects, and measurable milestones.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown("<br/>", unsafe_allow_html=True)

    # How it Works Timeline Card
    st.markdown(
        """
        <div class="advisor-card">
            <h4 style="margin-top:0; color:#1E3A8A;">How Career Path Advisor Works</h4>
            <div style="display: flex; gap: 16px; flex-wrap: wrap; margin-top: 14px;">
                <div style="flex: 1; min-width: 220px; background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 12px; padding: 16px;">
                    <span style="font-weight: 800; color: #2563EB;">STEP 1</span>
                    <h5 style="margin: 6px 0; color: #0F172A;">Share Your Profile</h5>
                    <p style="color: #64748B; font-size: 0.85rem; margin:0;">Enter your academic background, favourite subjects, tech stack, and personal career ambitions.</p>
                </div>
                <div style="flex: 1; min-width: 220px; background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 12px; padding: 16px;">
                    <span style="font-weight: 800; color: #7C3AED;">STEP 2</span>
                    <h5 style="margin: 6px 0; color: #0F172A;">Gemini LLM Analysis</h5>
                    <p style="color: #64748B; font-size: 0.85rem; margin:0;">The AI engine evaluates your strengths, working style, and learning availability using strict JSON schemas.</p>
                </div>
                <div style="flex: 1; min-width: 220px; background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 12px; padding: 16px;">
                    <span style="font-weight: 800; color: #059669;">STEP 3</span>
                    <h5 style="margin: 6px 0; color: #0F172A;">Roadmap & PDF Report</h5>
                    <p style="color: #64748B; font-size: 0.85rem; margin:0;">Explore side-by-side career comparisons, weekly curriculums, and download a professional PDF report.</p>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("<br/>", unsafe_allow_html=True)

    # Primary Call to Action Button
    cta_col1, cta_col2, cta_col3 = st.columns([1, 2, 1])
    with cta_col2:
        if st.button("🚀 Start Career Assessment", type="primary", use_container_width=True):
            navigate_to("assessment")
            st.rerun()


# ==============================================================================
# SECTION B: STUDENT PROFILE / CAREER ASSESSMENT FORM
# ==============================================================================
elif st.session_state.current_view == "assessment":
    st.markdown(
        """
        <div class="hero-badge">
            📝 STEP 1 OF 2 | ASSESSMENT QUESTIONNAIRE
        </div>
        <h2 style="margin: 0 0 6px 0; color: #0F172A; font-weight: 800;">Student Career Assessment</h2>
        <p style="color: #64748B; font-size: 0.98rem; margin-bottom: 24px;">
            Fill in your educational background, technical capabilities, and career goals to generate personalized recommendations.
        </p>
        """,
        unsafe_allow_html=True,
    )

    # Questionnaire Form
    with st.form("career_assessment_form"):
        # Section 1: Academic & Personal Background
        st.markdown("#### 1. Academic & Personal Background")
        c1, c2, c3 = st.columns(3)

        with c1:
            name_val = st.text_input(
                "Student Name *",
                value=st.session_state.form_data.get("student_name", ""),
                placeholder="e.g. Arjun Sharma",
            )

        with c2:
            edu_options = ["Undergraduate", "Postgraduate", "Diploma", "Other"]
            edu_idx = (
                edu_options.index(st.session_state.form_data.get("education_level", "Undergraduate"))
                if st.session_state.form_data.get("education_level") in edu_options
                else 0
            )
            edu_val = st.selectbox("Education Level *", options=edu_options, index=edu_idx)

        with c3:
            branch_options = [
                "Computer Science",
                "Information Technology",
                "Electronics",
                "Mechanical",
                "Civil",
                "Commerce",
                "Arts",
                "Other",
            ]
            branch_idx = (
                branch_options.index(st.session_state.form_data.get("degree_branch", "Computer Science"))
                if st.session_state.form_data.get("degree_branch") in branch_options
                else 0
            )
            branch_val = st.selectbox("Degree / Branch *", options=branch_options, index=branch_idx)

        st.markdown("<hr style='margin: 16px 0; border: none; border-top: 1px solid #E2E8F0;'/>", unsafe_allow_html=True)

        # Section 2: Academic Subjects & Technical Skills
        st.markdown("#### 2. Academic Preferences & Technical Skills")
        c4, c5 = st.columns(2)

        with c4:
            all_subjects = [
                "Programming",
                "Mathematics",
                "Database Management",
                "Artificial Intelligence",
                "Machine Learning",
                "Web Development",
                "Business Management",
                "Communication",
                "Design",
                "Other",
            ]
            default_subjects = [
                s for s in st.session_state.form_data.get("favourite_subjects", []) if s in all_subjects
            ]
            subjects_val = st.multiselect(
                "Favourite Academic Subjects *",
                options=all_subjects,
                default=default_subjects,
                help="Select subjects you genuinely enjoy studying or scoring well in.",
            )

        with c5:
            all_skills = [
                "Java",
                "Python",
                "C/C++",
                "JavaScript",
                "SQL",
                "HTML/CSS",
                "React",
                "Spring Boot",
                "Data Analysis",
                "Machine Learning",
                "Other",
            ]
            default_skills = [
                s for s in st.session_state.form_data.get("technical_skills", []) if s in all_skills
            ]
            skills_val = st.multiselect(
                "Current Technical Skills *",
                options=all_skills,
                default=default_skills,
                help="Languages, frameworks, or databases you have written code in.",
            )

        st.markdown("<hr style='margin: 16px 0; border: none; border-top: 1px solid #E2E8F0;'/>", unsafe_allow_html=True)

        # Section 3: Interests, Strengths & Working Style
        st.markdown("#### 3. Personal Interests & Strengths")
        c6, c7, c8 = st.columns(3)

        with c6:
            all_interests = [
                "Software Development",
                "Artificial Intelligence",
                "Data Science",
                "Cybersecurity",
                "Web Development",
                "Business and Management",
                "Designing and Creativity",
                "Problem Solving",
                "Research",
                "Entrepreneurship",
            ]
            default_interests = [
                i for i in st.session_state.form_data.get("personal_interests", []) if i in all_interests
            ]
            interests_val = st.multiselect(
                "Personal Interests *",
                options=all_interests,
                default=default_interests,
            )

        with c7:
            all_strengths = [
                "Problem Solving",
                "Logical Thinking",
                "Communication",
                "Creativity",
                "Leadership",
                "Analytical Thinking",
                "Teamwork",
            ]
            default_strengths = [
                s for s in st.session_state.form_data.get("strongest_skills", []) if s in all_strengths
            ]
            strengths_val = st.multiselect(
                "Strongest Personal / Soft Skills *",
                options=all_strengths,
                default=default_strengths,
            )

        with c8:
            style_options = ["Individual Work", "Team Work", "Both"]
            style_idx = (
                style_options.index(st.session_state.form_data.get("preferred_working_style", "Both"))
                if st.session_state.form_data.get("preferred_working_style") in style_options
                else 2
            )
            style_val = st.radio("Preferred Working Style *", options=style_options, index=style_idx)

        st.markdown("<hr style='margin: 16px 0; border: none; border-top: 1px solid #E2E8F0;'/>", unsafe_allow_html=True)

        # Section 4: Career Goals, Availability & Additional Context
        st.markdown("#### 4. Career Vision & Learning Bandwidth")
        c9, c10, c11 = st.columns(3)

        with c9:
            goal_options = [
                "Software Developer",
                "Data Scientist",
                "AI/ML Engineer",
                "Web Developer",
                "Business Analyst",
                "Cybersecurity Analyst",
                "Not Sure Yet",
            ]
            goal_idx = (
                goal_options.index(st.session_state.form_data.get("career_goal", "Software Developer"))
                if st.session_state.form_data.get("career_goal") in goal_options
                else 0
            )
            goal_val = st.selectbox("Aspirational Career Goal *", options=goal_options, index=goal_idx)

        with c10:
            exp_options = ["Beginner", "Intermediate", "Advanced"]
            exp_idx = (
                exp_options.index(st.session_state.form_data.get("experience_level", "Beginner"))
                if st.session_state.form_data.get("experience_level") in exp_options
                else 0
            )
            exp_val = st.selectbox("Technical Experience Level *", options=exp_options, index=exp_idx)

        with c11:
            avail_options = ["1 Hour", "2 Hours", "3 Hours", "4+ Hours"]
            avail_idx = (
                avail_options.index(st.session_state.form_data.get("daily_learning_availability", "2 Hours"))
                if st.session_state.form_data.get("daily_learning_availability") in avail_options
                else 1
            )
            avail_val = st.selectbox("Daily Learning Availability *", options=avail_options, index=avail_idx)

        add_info_val = st.text_area(
            "Additional Context, Ambitions, or Constraints (Optional)",
            value=st.session_state.form_data.get("additional_info", ""),
            placeholder="e.g. Interested in cloud microservices; looking for remote internships; prefer backend over visual design...",
            help="Any extra detail helps the Gemini LLM provide sharper recommendations.",
        )

        submit_btn = st.form_submit_button("🔍 Analyse My Career Profile", type="primary", use_container_width=True)

    # Handle Form Submission
    if submit_btn:
        profile_payload = {
            "student_name": name_val.strip(),
            "education_level": edu_val,
            "degree_branch": branch_val,
            "favourite_subjects": subjects_val,
            "technical_skills": skills_val,
            "personal_interests": interests_val,
            "strongest_skills": strengths_val,
            "preferred_working_style": style_val,
            "career_goal": goal_val,
            "experience_level": exp_val,
            "daily_learning_availability": avail_val,
            "additional_info": add_info_val.strip(),
        }

        # Store in session state form_data for persistence
        st.session_state.form_data = profile_payload
        st.session_state.student_profile = profile_payload

        # Validate inputs
        is_valid, validation_errors = validate_inputs(profile_payload)
        if not is_valid:
            for err in validation_errors:
                st.error(f"⚠️ {err}")
        else:
            with st.spinner("🤖 Gemini AI is analysing your profile and crafting your 90-day roadmaps..."):
                try:
                    result_data, is_live, msg = analyze_career_profile(
                        profile_payload,
                        api_key=api_key_input,
                        allow_simulation_fallback=True,
                    )
                    st.session_state.analysis_result = result_data
                    st.session_state.api_message = msg
                    st.session_state.current_view = "results"
                    st.rerun()
                except Exception as ex:
                    st.error(f"Error during career profile analysis: {str(ex)}")


# ==============================================================================
# SECTION C: RESULTS DASHBOARD (RECOMMENDATIONS, ROADMAP, GAP ANALYSIS, PDF)
# ==============================================================================
elif st.session_state.current_view == "results":
    if not st.session_state.analysis_result:
        st.warning("No career analysis results found. Please complete the assessment questionnaire first.")
        if st.button("Go to Assessment"):
            navigate_to("assessment")
            st.rerun()
        st.stop()

    data = st.session_state.analysis_result
    profile = st.session_state.student_profile
    recs = data.get("career_recommendations", [])

    # Header with Back / Action buttons
    top_c1, top_c2, top_c3 = st.columns([2, 1, 1])
    with top_c1:
        st.markdown(
            """
            <div class="hero-badge">
                🎯 STEP 2 OF 2 | CAREER ANALYSIS & ROADMAP
            </div>
            <h2 style="margin: 0; color: #0F172A; font-weight: 800;">Career Recommendation Report</h2>
            """,
            unsafe_allow_html=True,
        )
    with top_c2:
        # Download PDF Report button
        try:
            pdf_bytes = generate_pdf_report(profile, data)
            st.download_button(
                label="📄 Download PDF Report",
                data=pdf_bytes,
                file_name=f"{profile.get('student_name', 'Student').replace(' ', '_')}_Career_Roadmap.pdf",
                mime="application/pdf",
                use_container_width=True,
            )
        except Exception as e:
            st.error(f"PDF creation error: {e}")
    with top_c3:
        if st.button("✏️ Edit Profile", use_container_width=True):
            navigate_to("assessment")
            st.rerun()

    # API Status alert if simulation or live
    if st.session_state.api_message:
        if "Notice" in st.session_state.api_message or "Alert" in st.session_state.api_message:
            st.info(st.session_state.api_message)
        else:
            st.success(st.session_state.api_message)

    # 1. Student Profile Summary Card
    st.markdown(
        f"""
        <div class="advisor-card" style="background: linear-gradient(135deg, #F0F7FF 0%, #FFFFFF 100%);">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap;">
                <div>
                    <h3 style="margin: 0 0 4px 0; color: #1E3A8A;">Student: {profile.get('student_name', 'Student')}</h3>
                    <p style="color: #64748B; font-size: 0.9rem; margin-bottom: 8px;">
                        <b>Education:</b> {profile.get('education_level')} in {profile.get('degree_branch')} &bull;
                        <b>Experience:</b> {profile.get('experience_level')} &bull;
                        <b>Daily Bandwidth:</b> {profile.get('daily_learning_availability')} &bull;
                        <b>Style:</b> {profile.get('preferred_working_style')}
                    </p>
                </div>
                <div style="text-align: right;">
                    <span class="hero-badge" style="background:#DBEAFE; color:#1E40AF;">Target Goal: {profile.get('career_goal')}</span>
                </div>
            </div>
            <p style="color: #334155; font-size: 0.96rem; line-height: 1.55; margin-top: 10px; border-top: 1px dashed #CBD5E1; padding-top: 10px;">
                <b>AI Profile Synthesis:</b> {data.get('profile_summary', '')}
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("### 🏆 Top 3 Recommended Career Pathways")
    st.caption("Click on any career card to select it for deep-dive skill gap analysis and weekly roadmap review:")

    # Render 3 Career Cards Side-by-Side
    card_cols = st.columns(3)
    for idx, rec in enumerate(recs):
        with card_cols[idx]:
            score = rec.get("suitability_score", 85)
            is_selected = (idx == st.session_state.selected_career_idx)
            border_style = "2px solid #2563EB" if is_selected else "1px solid #E2E8F0"
            bg_style = "#F0F7FF" if is_selected else "#FFFFFF"

            st.markdown(
                f"""
                <div class="advisor-card" style="background: {bg_style}; border: {border_style}; min-height: 480px; display: flex; flex-direction: column; justify-content: space-between;">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                            <span style="font-size: 0.8rem; font-weight: 800; color: #4F46E5;">OPTION #{idx+1}</span>
                            <span class="score-badge">{score}%</span>
                        </div>
                        <h4 style="margin: 0 0 8px 0; color: #0F172A; font-weight: 700;">{rec.get('career_title')}</h4>
                        <div style="margin-bottom: 12px;">
                            <div style="background: #E2E8F0; border-radius: 9999px; height: 8px; width: 100%; overflow: hidden;">
                                <div style="background: linear-gradient(90deg, #2563EB, #7C3AED); width: {score}%; height: 100%;"></div>
                            </div>
                        </div>
                        <p style="color: #475569; font-size: 0.86rem; line-height: 1.45; margin-bottom: 14px;">
                            {rec.get('career_overview')}
                        </p>
                        <div style="margin-bottom: 10px;">
                            <b style="font-size: 0.8rem; color: #1E293B;">Key Advantage:</b>
                            <p style="font-size: 0.82rem; color: #64748B; margin: 2px 0 6px 0;">
                                {rec.get('why_suitable', ['Directly aligns with your strengths'])[0]}
                            </p>
                        </div>
                        <div style="margin-bottom: 8px;">
                            <b style="font-size: 0.8rem; color: #1E293B;">Core Tech:</b><br/>
                            {' '.join([f'<span class=\"tag-pill tag-tool\">{t}</span>' for t in rec.get('tools_and_technologies', [])[:4]])}
                        </div>
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )
            btn_label = "✅ Currently Selected" if is_selected else f"Select Option #{idx+1}"
            if st.button(btn_label, key=f"select_career_{idx}", use_container_width=True):
                st.session_state.selected_career_idx = idx
                st.rerun()

    # Active Career Deep Dive Details
    active_rec = recs[st.session_state.selected_career_idx]
    st.markdown("<br/>", unsafe_allow_html=True)

    st.markdown(
        f"""
        <div class="advisor-card" style="border-top: 4px solid #4F46E5;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
                <div>
                    <span class="hero-badge">SELECTED CAREER DEEP DIVE</span>
                    <h3 style="margin: 4px 0; color: #0F172A;">{active_rec.get('career_title')} ({active_rec.get('suitability_score')}% Match)</h3>
                </div>
            </div>
            <p style="color: #475569; font-size: 0.95rem; margin-top: 8px;">
                {active_rec.get('career_overview')}
            </p>
            <div style="display: flex; gap: 20px; flex-wrap: wrap; margin-top: 14px;">
                <div style="flex: 1; min-width: 280px;">
                    <b style="color: #1E293B; font-size: 0.9rem;">Why This Career Fits Your Profile:</b>
                    <ul style="color: #475569; font-size: 0.88rem; margin: 6px 0 0 16px; padding: 0;">
                        {''.join([f'<li>{r}</li>' for r in active_rec.get('why_suitable', [])])}
                    </ul>
                </div>
                <div style="flex: 1; min-width: 280px;">
                    <b style="color: #1E293B; font-size: 0.9rem;">Suggested Hands-On Portfolio Projects:</b>
                    <ul style="color: #475569; font-size: 0.88rem; margin: 6px 0 0 16px; padding: 0;">
                        {''.join([f'<li>{p}</li>' for p in active_rec.get('suggested_projects', [])])}
                    </ul>
                </div>
                <div style="flex: 1; min-width: 240px;">
                    <b style="color: #1E293B; font-size: 0.9rem;">Potential Job Roles:</b><br/>
                    {' '.join([f'<span class=\"tag-pill tag-role\">{jr}</span>' for jr in active_rec.get('job_roles', [])])}
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # 2. Dedicated Skill Gap Analysis Section
    st.markdown("### 📊 Skill Gap Analysis")
    st.caption("Comparison between your verified current capabilities and the requisite industry competencies:")

    gap_c1, gap_c2, gap_c3 = st.columns(3)

    with gap_c1:
        st.markdown(
            f"""
            <div class="advisor-card" style="border-top: 4px solid #059669; min-height: 240px;">
                <h4 style="margin: 0 0 8px 0; color: #065F46;">✅ Skills You Possess</h4>
                <p style="color: #64748B; font-size: 0.82rem; margin-bottom: 12px;">Foundational or matching skills already verified from your assessment:</p>
                {' '.join([f'<span class=\"tag-pill tag-match\">✓ {s}</span>' for s in active_rec.get('existing_relevant_skills', [])])}
            </div>
            """,
            unsafe_allow_html=True,
        )

    with gap_c2:
        st.markdown(
            f"""
            <div class="advisor-card" style="border-top: 4px solid #D97706; min-height: 240px;">
                <h4 style="margin: 0 0 8px 0; color: #92400E;">⚠️ Skill Gaps (To Develop)</h4>
                <p style="color: #64748B; font-size: 0.82rem; margin-bottom: 12px;">Target competencies you must build over the next 90 days:</p>
                {' '.join([f'<span class=\"tag-pill tag-missing\">+ {s}</span>' for s in active_rec.get('missing_skills', [])])}
            </div>
            """,
            unsafe_allow_html=True,
        )

    with gap_c3:
        st.markdown(
            f"""
            <div class="advisor-card" style="border-top: 4px solid #2563EB; min-height: 240px;">
                <h4 style="margin: 0 0 8px 0; color: #1E40AF;">🛠️ Priority Tech Stack</h4>
                <p style="color: #64748B; font-size: 0.82rem; margin-bottom: 12px;">Essential tools, libraries, and frameworks recommended for mastery:</p>
                {' '.join([f'<span class=\"tag-pill tag-tool\">⚡ {t}</span>' for t in active_rec.get('tools_and_technologies', [])])}
            </div>
            """,
            unsafe_allow_html=True,
        )

    # 3. Dedicated Three-Month Learning Roadmap Section
    st.markdown("### 📅 Three-Month Learning Roadmap")
    st.markdown(
        f"Customized weekly action curriculum for **{active_rec.get('career_title')}**, budgeted for **{profile.get('daily_learning_availability', '2 Hours')}** per day:"
    )

    roadmap_data = active_rec.get("roadmap", {})
    m1_tab, m2_tab, m3_tab = st.tabs([
        "📘 Month 1: Foundation",
        "⚙️ Month 2: Skill Development",
        "🚀 Month 3: Practical Implementation",
    ])

    def render_month_weeks(month_key: str):
        month_obj = roadmap_data.get(month_key, {})
        weeks = month_obj.get("weeks", [])
        if not weeks:
            st.info("Curriculum details being prepared.")
            return

        for w in weeks:
            w_num = w.get("week", 1)
            topics = w.get("topics", [])
            tasks = w.get("tasks", [])
            outcome = w.get("outcome", "")

            with st.container():
                st.markdown(
                    f"""
                    <div class="week-box">
                        <div class="week-title">🗓️ Week {w_num}</div>
                        <div style="display: flex; gap: 20px; flex-wrap: wrap;">
                            <div style="flex: 1; min-width: 250px;">
                                <b style="font-size: 0.85rem; color: #1E293B;">📖 Topics & Concepts:</b>
                                <ul style="color: #475569; font-size: 0.85rem; margin: 4px 0 0 16px; padding: 0;">
                                    {''.join([f'<li>{t}</li>' for t in topics])}
                                </ul>
                            </div>
                            <div style="flex: 1; min-width: 250px;">
                                <b style="font-size: 0.85rem; color: #1E293B;">💻 Hands-On Tasks & Exercises:</b>
                                <ul style="color: #475569; font-size: 0.85rem; margin: 4px 0 0 16px; padding: 0;">
                                    {''.join([f'<li>{t}</li>' for t in tasks])}
                                </ul>
                            </div>
                        </div>
                        <div style="margin-top: 8px; padding-top: 6px; border-top: 1px dashed #CBD5E1;">
                            <span style="font-size: 0.82rem; font-weight: 700; color: #059669;">🎯 Measurable Milestone:</span>
                            <span style="font-size: 0.82rem; color: #334155;">{outcome}</span>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

    with m1_tab:
        render_month_weeks("month_1")

    with m2_tab:
        render_month_weeks("month_2")

    with m3_tab:
        render_month_weeks("month_3")

    # 4. Career Comparison Matrix Section
    st.markdown("### ⚖️ Side-by-Side Career Comparison")
    st.caption("Evaluate all three options simultaneously across suitability, tools, and roles:")

    comparison_rows = []
    for i, r in enumerate(recs):
        comparison_rows.append({
            "Career Option": f"#{i+1}: {r.get('career_title')}",
            "Suitability Match": f"{r.get('suitability_score')}%",
            "Core Technologies": ", ".join(r.get("tools_and_technologies", [])[:4]),
            "Key Advantage": r.get("why_suitable", ["High fit"])[0],
            "Target Entry Roles": ", ".join(r.get("job_roles", [])[:3]),
        })

    df_comp = pd.DataFrame(comparison_rows)
    st.dataframe(df_comp, use_container_width=True, hide_index=True)

    # 5. Overall Recommendation Banner
    st.markdown(
        f"""
        <div class="advisor-card" style="background: linear-gradient(135deg, #EEF2FF 0%, #FFFFFF 100%); border-left: 6px solid #4F46E5; margin-top: 20px;">
            <h4 style="margin: 0 0 6px 0; color: #312E81;">💡 AI Counsellor Final Guidance</h4>
            <p style="color: #3730A3; font-size: 0.95rem; line-height: 1.6; margin: 0;">
                {data.get('overall_recommendation', 'Focus on continuous daily practice and project documentation.')}
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Footer navigation
    f_c1, f_c2 = st.columns(2)
    with f_c1:
        if st.button("🔄 Retake Career Assessment", use_container_width=True):
            reset_assessment()
            st.rerun()
    with f_c2:
        if st.button("📄 Generate & Download Updated PDF", use_container_width=True):
            pdf_bytes = generate_pdf_report(profile, data)
            st.download_button(
                label="Click to Save PDF File",
                data=pdf_bytes,
                file_name=f"{profile.get('student_name', 'Student').replace(' ', '_')}_Career_Roadmap.pdf",
                mime="application/pdf",
                use_container_width=True,
            )
